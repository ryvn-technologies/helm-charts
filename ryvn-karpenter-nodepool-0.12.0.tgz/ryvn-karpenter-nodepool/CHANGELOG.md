# Changelog

## [0.11.3](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.11.2...ryvn-karpenter-nodepool@v0.11.3) (2026-01-04)


### Bug Fixes

* use only one bottlerocket alias ([086ce83](https://github.com/ryvn-technologies/ryvn/commit/086ce83f2be6247a75de6ea9a0dd4e3276dc7e69))

## [0.11.2](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.11.1...ryvn-karpenter-nodepool@v0.11.2) (2026-01-04)


### Bug Fixes

* specify higher bottlerocket version ([#3640](https://github.com/ryvn-technologies/ryvn/issues/3640)) ([8b7f31e](https://github.com/ryvn-technologies/ryvn/commit/8b7f31e824524979ec776539fe3a5ce63a61df2a))

## [0.11.1](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.11.0...ryvn-karpenter-nodepool@v0.11.1) (2025-12-15)


### Bug Fixes

* adjust budget ([52f49d0](https://github.com/ryvn-technologies/ryvn/commit/52f49d0f6e18af83255c25deb7e9d1dcfac1975f))

## [0.11.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.10.2...ryvn-karpenter-nodepool@v0.11.0) (2025-10-29)


### Features

* add instanceStorePolicy support to Karpenter nodepool chart ([#3052](https://github.com/ryvn-technologies/ryvn/issues/3052)) ([20c1785](https://github.com/ryvn-technologies/ryvn/commit/20c1785982f026bd4d9985ae2f160a2ec64c6fd8))

## [0.10.2](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.10.1...ryvn-karpenter-nodepool@v0.10.2) (2025-10-22)


### Bug Fixes

* bump emphemeral storage ([73afa77](https://github.com/ryvn-technologies/ryvn/commit/73afa77f7ddf8ffa2d1885ca114dd35f715be7c6))
* remove c series from instance types ([c1535e4](https://github.com/ryvn-technologies/ryvn/commit/c1535e4f7aac640585b913660fdd0b25cf90bbb0))

## [0.10.1](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.10.0...ryvn-karpenter-nodepool@v0.10.1) (2025-09-16)


### Bug Fixes

* tweak budget to minimize underutilized disruptions during business hours (EST skewed) ([#2634](https://github.com/ryvn-technologies/ryvn/issues/2634)) ([7bcca71](https://github.com/ryvn-technologies/ryvn/commit/7bcca71da75e795a9cb85a5537098088266a833b))

## [0.10.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-karpenter-nodepool@v0.9.0...ryvn-karpenter-nodepool@v0.10.0) (2025-09-13)


### Features

* add device block mappings to ryvn-karpenter-nodepool ([#2241](https://github.com/ryvn-technologies/ryvn/issues/2241)) ([336652f](https://github.com/ryvn-technologies/ryvn/commit/336652f177bdf5479d25dea39001afbc8c93c72e))
* add some sane budgets to default nodepool ([#2568](https://github.com/ryvn-technologies/ryvn/issues/2568)) ([4a689df](https://github.com/ryvn-technologies/ryvn/commit/4a689df0abcfee08a16fbe8ed7af1d0147d0d142))
* more karpenter nodepool requirements ([#2613](https://github.com/ryvn-technologies/ryvn/issues/2613)) ([ecd180a](https://github.com/ryvn-technologies/ryvn/commit/ecd180a111169c9f0ec9715335d7a8e2d272d82f))
* **nodepool-chart:** allow additional node classes  ([#2531](https://github.com/ryvn-technologies/ryvn/issues/2531)) ([4fcd1d6](https://github.com/ryvn-technologies/ryvn/commit/4fcd1d69019393697a22e48da8e11deed93295f6))


### Bug Fixes

* pin bottlerocket AMI ([#2174](https://github.com/ryvn-technologies/ryvn/issues/2174)) ([ed4bd0a](https://github.com/ryvn-technologies/ryvn/commit/ed4bd0a73cd2ab725b739e2acde5e923b58f27ac))
* remove t class nodes from karpeter ([#2362](https://github.com/ryvn-technologies/ryvn/issues/2362)) ([54be011](https://github.com/ryvn-technologies/ryvn/commit/54be0110cf6c5debad31c622211a104fd495372c))
* set version for karpenter module  ([#2363](https://github.com/ryvn-technologies/ryvn/issues/2363)) ([3e23cfe](https://github.com/ryvn-technologies/ryvn/commit/3e23cfe8e65ac2e63953b8f561558d07c56125e6))
* update ryvn-karpenter-nodepool to 0.7.0 ([#2487](https://github.com/ryvn-technologies/ryvn/issues/2487)) ([80516cd](https://github.com/ryvn-technologies/ryvn/commit/80516cdd68e1abc62e927feae1951814de2625d8))
