# Changelog

## 0.1.2 (2026-03-06)

### Fixes

* replace string-based `defaults.maxBodySize` parsing with typed `defaults.maxBodySizeBytes`
* validate `defaults.maxBodySizeBytes` via `values.schema.json` instead of template-side conversion logic

## 0.1.1 (2026-03-06)

### Fixes

* match EnvoyFilter workload selectors to the upstream gateway chart's `istio` label behavior
* validate and normalize `defaults.maxBodySize.value` parsing instead of silently rendering invalid sizes as `0`
* disable `defaults.maxBodySize` by default to keep request bodies unlimited until an explicit baseline is chosen

## 0.1.0 (2026-03-04)

### Features

* initial release wrapping Istio gateway 1.29.0 with gateway-wide Envoy defaults
* add `defaults.maxBodySize` for gateway-wide request body size limit via EnvoyFilter
