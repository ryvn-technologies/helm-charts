{{/*
Expand the name of the chart.
*/}}
{{- define "ryvn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ryvn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ryvn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ryvn-gateway.labels" -}}
helm.sh/chart: {{ include "ryvn-gateway.chart" . }}
{{ include "ryvn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ryvn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Resolve the upstream gateway chart's istio selector label for EnvoyFilter workloadSelector.
The upstream chart derives this from gateway.labels.istio when set, otherwise from the
gateway name with any leading "istio-" prefix removed.
*/}}
{{- define "ryvn-gateway.gatewayIstioLabel" -}}
{{- $gateway := default (dict) .Values.gateway -}}
{{- $labels := default (dict) $gateway.labels -}}
{{- if hasKey $labels "istio" -}}
{{- index $labels "istio" -}}
{{- else -}}
{{- $name := default .Release.Name $gateway.name -}}
{{- trimPrefix "istio-" $name -}}
{{- end -}}
{{- end }}
