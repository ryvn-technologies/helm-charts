package admission_test

import (
	"strings"
	"testing"

	"github.com/stretchr/testify/require"
	"helm.sh/helm/v4/pkg/chart/common"
	chartutil "helm.sh/helm/v4/pkg/chart/common/util"
	"helm.sh/helm/v4/pkg/chart/v2/loader"
	"helm.sh/helm/v4/pkg/engine"
	admissionregistrationv1 "k8s.io/api/admissionregistration/v1"
	corev1 "k8s.io/api/core/v1"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/apis/meta/v1/unstructured"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	"k8s.io/apimachinery/pkg/util/yaml"
	"k8s.io/apiserver/pkg/admission"
	admissioncel "k8s.io/apiserver/pkg/admission/plugin/cel"
	"k8s.io/apiserver/pkg/admission/plugin/policy/generic"
	"k8s.io/apiserver/pkg/admission/plugin/policy/matching"
	"k8s.io/apiserver/pkg/admission/plugin/policy/validating"
	"k8s.io/apiserver/pkg/admission/plugin/webhook/matchconditions"
	celconfig "k8s.io/apiserver/pkg/apis/cel"
	"k8s.io/apiserver/pkg/authentication/user"
	"k8s.io/apiserver/pkg/cel/environment"
	corelisters "k8s.io/client-go/listers/core/v1"
	"k8s.io/client-go/tools/cache"
)

func TestIstioMetadata(t *testing.T) {
	policy := renderPolicy(t, "istio-metadata", nil)
	for _, field := range []string{"labels", "annotations"} {
		for _, test := range []struct {
			name, key, value, oldValue string
			operation                  admission.Operation
			allowed                    bool
		}{
			{name: "plain metadata", key: "app", value: "example", allowed: true},
			{name: "istio domain", key: "istio.io/dataplane-mode", value: "ambient"},
			{name: "istio subdomain", key: "ambient.istio.io/bypass-inbound-capture", value: "true"},
			{name: "legacy injection", key: "istio-injection", value: "enabled"},
			{name: "similar domain", key: "example-istio.io/setting", value: "true", allowed: true},
			{name: "sidecar opt out", key: "sidecar.istio.io/inject", value: "false", allowed: true},
			{name: "sidecar opt in", key: "sidecar.istio.io/inject", value: "true"},
			{name: "add on update", key: "istio.io/use-waypoint", value: "waypoint", operation: admission.Update},
			{name: "preserve existing key", key: "ambient.istio.io/redirection", value: "enabled", oldValue: "enabled", operation: admission.Update, allowed: true},
			{name: "change existing key", key: "ambient.istio.io/redirection", value: "disabled", oldValue: "enabled", operation: admission.Update},
			{name: "remove existing key", key: "istio-injection", oldValue: "enabled", operation: admission.Update, allowed: true},
			{name: "disable sidecar", key: "sidecar.istio.io/inject", value: "false", oldValue: "true", operation: admission.Update, allowed: true},
		} {
			t.Run(field+"/"+test.name, func(t *testing.T) {
				object := policyObject("Pod", "example", "workloads")
				oldObject := object.DeepCopy()
				if test.value != "" {
					object.Object["metadata"].(map[string]any)[field] = map[string]any{test.key: test.value}
				}
				if test.oldValue != "" {
					oldObject.Object["metadata"].(map[string]any)[field] = map[string]any{test.key: test.oldValue}
				}
				operation := test.operation
				if operation == "" {
					operation = admission.Create
				}
				request := policyRequest{object: object, operation: operation, resource: "pods"}
				if operation == admission.Update {
					request.oldObject = oldObject
				}
				require.Equal(t, test.allowed, policy.admits(t, request))
			})
		}
	}

	t.Run("pods status remains writable by istio cni", func(t *testing.T) {
		oldObject := policyObject("Pod", "example", "workloads")
		object := oldObject.DeepCopy()
		object.SetAnnotations(map[string]string{"ambient.istio.io/redirection": "enabled"})
		require.True(t, policy.admits(t, policyRequest{
			object: object, oldObject: oldObject, operation: admission.Update, resource: "pods", subresource: "status",
		}))
	})

	t.Run("cert-manager http-01 solver service", func(t *testing.T) {
		const certManager = "system:serviceaccount:cert-manager:cert-manager"
		for _, test := range []struct {
			name, username, value string
			allowed               bool
		}{
			{name: "cert-manager", username: certManager, value: "NONE", allowed: true},
			{name: "customer", value: "NONE"},
			{name: "other value", username: certManager, value: "MUTUAL_TLS"},
		} {
			t.Run(test.name, func(t *testing.T) {
				object := policyObject("Service", "cm-acme-http-solver-x7k2p", "workloads")
				object.SetAnnotations(map[string]string{"auth.istio.io/8089": test.value})
				require.Equal(t, test.allowed, policy.admits(t, policyRequest{
					object: object, operation: admission.Create, resource: "services", username: test.username,
				}))
			})
		}
	})
}

func TestIstioMetadataNamespaces(t *testing.T) {
	for _, config := range []struct {
		name    string
		values  map[string]any
		allowed []string
		denied  []string
	}{
		{name: "defaults", allowed: []string{"ryvn-system", "external-ingress-nginx", "internal-ingress-nginx"}, denied: []string{"workloads"}},
		{
			name: "overrides",
			values: map[string]any{
				"networking": map[string]any{"managedGatewayNamespaces": []any{"gateway-system"}},
				"istiod":     map[string]any{"namespace": "mesh-system"},
			},
			allowed: []string{"gateway-system", "mesh-system"}, denied: []string{"ryvn-system", "workloads"},
		},
	} {
		t.Run(config.name, func(t *testing.T) {
			policy := renderPolicy(t, "istio-metadata", config.values)
			for _, resource := range []struct{ kind, name string }{{"Namespace", "namespaces"}, {"Pod", "pods"}, {"Service", "services"}} {
				for _, allowed := range []bool{true, false} {
					namespaces := config.denied
					if allowed {
						namespaces = config.allowed
					}
					for _, namespace := range namespaces {
						t.Run(resource.kind+"/"+namespace, func(t *testing.T) {
							object := policyObject(resource.kind, "example", namespace)
							object.SetLabels(map[string]string{"istio.io/dataplane-mode": "ambient"})
							if resource.kind == "Namespace" {
								object.SetName(namespace)
								object.SetNamespace("")
								object.SetLabels(map[string]string{"kubernetes.io/metadata.name": namespace, "istio.io/dataplane-mode": "ambient"})
							}
							require.Equal(t, allowed, policy.admits(t, policyRequest{object: object, resource: resource.name, operation: admission.Create}))
						})
					}
				}
			}
		})
	}
}

func TestIstioGatewayClasses(t *testing.T) {
	const istiod = "system:serviceaccount:ryvn-system:istiod"
	for _, config := range []struct {
		name   string
		values map[string]any
		custom bool
	}{
		{name: "defaults"},
		{name: "custom class", custom: true, values: map[string]any{"networking": map[string]any{
			"managedGatewayClasses": []any{"ryvn-istio", "istio-remote", "istio-waypoint", "istio-east-west", "custom-istio"},
		}}},
	} {
		t.Run(config.name, func(t *testing.T) {
			policy := renderPolicy(t, "networking", config.values)
			for _, test := range []struct {
				name, class, controller, username string
				operation                         admission.Operation
				allowed                           bool
			}{
				{name: "customer custom istio", class: "custom-istio", controller: "istio.io/gateway-controller"},
				{name: "trusted custom istio", class: "custom-istio", controller: "istio.io/gateway-controller", username: istiod, allowed: config.custom},
				{name: "trusted managed istio", class: "ryvn-istio", controller: "istio.io/gateway-controller", username: istiod, allowed: true},
				{name: "customer envoy", class: "envoy", controller: "gateway.envoyproxy.io/gatewayclass-controller", allowed: true},
				{name: "customer custom update", class: "custom-istio", controller: "istio.io/gateway-controller", operation: admission.Update},
				{name: "customer custom delete", class: "custom-istio", controller: "istio.io/gateway-controller", operation: admission.Delete},
				{name: "cleanup custom update", class: "custom-istio", controller: "istio.io/gateway-controller", operation: admission.Update, username: "system:kube-controller-manager", allowed: true},
				{name: "cleanup custom delete", class: "custom-istio", controller: "istio.io/gateway-controller", operation: admission.Delete, username: "system:kube-controller-manager", allowed: true},
			} {
				t.Run(test.name, func(t *testing.T) {
					object := policyObject("GatewayClass", test.class, "")
					object.Object["spec"] = map[string]any{"controllerName": test.controller}
					request := policyRequest{object: object, resource: "gatewayclasses", operation: test.operation, username: test.username}
					if request.operation == "" {
						request.operation = admission.Create
					}
					if request.operation != admission.Create {
						request.oldObject = object.DeepCopy()
					}
					if request.operation == admission.Delete {
						request.object = nil
					}
					require.Equal(t, test.allowed, policy.admits(t, request))
				})
			}
			for _, class := range []string{"ryvn-istio", "istio-remote", "istio-waypoint", "istio-east-west", "envoy", "custom-istio"} {
				t.Run("gateway/"+class, func(t *testing.T) {
					object := policyObject("Gateway", "example", "workloads")
					object.Object["spec"] = map[string]any{"gatewayClassName": class}
					allowed := class == "envoy" || (class == "custom-istio" && !config.custom)
					require.Equal(t, allowed, policy.admits(t, policyRequest{object: object, resource: "gateways", operation: admission.Create}))
				})
			}
		})
	}
}

type policyRequest struct {
	object, oldObject     *unstructured.Unstructured
	resource, subresource string
	username              string
	operation             admission.Operation
}

type admissionPolicy struct {
	definition *admissionregistrationv1.ValidatingAdmissionPolicy
	validator  validating.Validator
}

func policyObject(kind, name, namespace string) *unstructured.Unstructured {
	object := &unstructured.Unstructured{}
	object.SetAPIVersion("v1")
	if kind == "Gateway" || kind == "GatewayClass" {
		object.SetAPIVersion("gateway.networking.k8s.io/v1")
	}
	object.SetKind(kind)
	object.SetName(name)
	object.SetNamespace(namespace)
	return object
}

// Render the shipped policy and compile its CEL using Kubernetes' admission
// compiler, including composed variables and match conditions.
func renderPolicy(t *testing.T, template string, values map[string]any) admissionPolicy {
	t.Helper()
	chart, err := loader.Load("..")
	require.NoError(t, err)
	renderValues, err := chartutil.ToRenderValues(chart, values, common.ReleaseOptions{Name: "ryvn-admission", Namespace: "ryvn-system"}, common.DefaultCapabilities)
	require.NoError(t, err)
	manifests, err := engine.Render(chart, renderValues)
	require.NoError(t, err)
	decoder := yaml.NewYAMLOrJSONDecoder(strings.NewReader(manifests["ryvn-admission/templates/"+template+".yaml"]), 4096)
	var policy admissionregistrationv1.ValidatingAdmissionPolicy
	require.NoError(t, decoder.Decode(&policy))
	var binding admissionregistrationv1.ValidatingAdmissionPolicyBinding
	require.NoError(t, decoder.Decode(&binding))
	require.Equal(t, policy.Name, binding.Spec.PolicyName)
	require.Contains(t, binding.Spec.ValidationActions, admissionregistrationv1.Deny)
	require.Equal(t, admissionregistrationv1.Fail, *policy.Spec.FailurePolicy)
	// The API server defaults omitted selectors to empty selectors.
	if policy.Spec.MatchConstraints.NamespaceSelector == nil {
		policy.Spec.MatchConstraints.NamespaceSelector = &metav1.LabelSelector{}
	}
	if policy.Spec.MatchConstraints.ObjectSelector == nil {
		policy.Spec.MatchConstraints.ObjectSelector = &metav1.LabelSelector{}
	}
	compiler, err := admissioncel.NewCompositedCompiler(environment.MustBaseEnvSet(environment.DefaultCompatibilityVersion()))
	require.NoError(t, err)
	options := admissioncel.OptionalVariableDeclarations{HasAuthorizer: true}
	for _, variable := range policy.Spec.Variables {
		result := compiler.CompileAndStoreVariable(&validating.Variable{Name: variable.Name, Expression: variable.Expression}, options, environment.StoredExpressions)
		require.Nil(t, result.Error)
	}
	compile := func(expressions []admissioncel.ExpressionAccessor) admissioncel.ConditionEvaluator {
		result := compiler.CompileCondition(expressions, options, environment.StoredExpressions)
		require.Empty(t, result.CompilationErrors())
		return result
	}
	conditions := make([]admissioncel.ExpressionAccessor, len(policy.Spec.MatchConditions))
	for i := range policy.Spec.MatchConditions {
		conditions[i] = (*matchconditions.MatchCondition)(&policy.Spec.MatchConditions[i])
	}
	validations := make([]admissioncel.ExpressionAccessor, len(policy.Spec.Validations))
	messages := make([]admissioncel.ExpressionAccessor, len(policy.Spec.Validations))
	for i, validation := range policy.Spec.Validations {
		validations[i] = &validating.ValidationCondition{Expression: validation.Expression, Message: validation.Message, Reason: validation.Reason}
		if validation.MessageExpression != "" {
			messages[i] = &validating.MessageExpressionCondition{MessageExpression: validation.MessageExpression}
		}
	}
	matcher := matchconditions.NewMatcher(compile(conditions), policy.Spec.FailurePolicy, "policy", "validate", policy.Name)
	return admissionPolicy{definition: &policy, validator: validating.NewValidator(compile(validations), matcher, compile(nil), compile(messages), policy.Spec.FailurePolicy, nil)}
}

func (p admissionPolicy) admits(t *testing.T, request policyRequest) bool {
	t.Helper()
	var object, oldObject runtime.Object
	if request.object != nil {
		object = request.object
	}
	if request.oldObject != nil {
		oldObject = request.oldObject
	}
	target := request.object
	if target == nil {
		target = request.oldObject
	}
	resource := schema.GroupVersionResource{Group: target.GroupVersionKind().Group, Version: "v1", Resource: request.resource}
	if request.username == "" {
		request.username = "customer"
	}
	attributes := admission.NewAttributesRecord(object, oldObject, target.GroupVersionKind(), target.GetNamespace(), target.GetName(), resource, request.subresource, request.operation, nil, false, &user.DefaultInfo{Name: request.username})
	namespace := &corev1.Namespace{ObjectMeta: metav1.ObjectMeta{Name: target.GetNamespace(), Labels: map[string]string{"kubernetes.io/metadata.name": target.GetNamespace()}}}
	indexer := cache.NewIndexer(cache.MetaNamespaceKeyFunc, cache.Indexers{})
	require.NoError(t, indexer.Add(namespace))
	matcher := generic.NewPolicyMatcher(matching.NewMatcher(corelisters.NewNamespaceLister(indexer), nil))
	matched, _, _, err := matcher.DefinitionMatches(attributes, admission.NewObjectInterfacesFromScheme(runtime.NewScheme()), validating.NewValidatingAdmissionPolicyAccessor(p.definition))
	require.NoError(t, err)
	if !matched {
		return true
	}
	result := p.validator.Validate(t.Context(), resource, &admission.VersionedAttributes{
		Attributes: attributes, VersionedObject: admission.NewLazyObject(object), VersionedOldObject: admission.NewLazyObject(oldObject), VersionedKind: target.GroupVersionKind(),
	}, nil, namespace, celconfig.RuntimeCELCostBudget, nil)
	for _, decision := range result.Decisions {
		require.NotEqual(t, validating.EvalError, decision.Evaluation, decision.Message)
		if decision.Action == validating.ActionDeny {
			return false
		}
	}
	return true
}
