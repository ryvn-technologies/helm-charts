package collector_test

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"slices"
	"strings"
	"sync"
	"testing"
	"text/template"
	"time"

	"github.com/Masterminds/sprig/v3"
	"github.com/golang/snappy"
	"github.com/prometheus/prometheus/prompb"
	"gopkg.in/yaml.v3"
)

// Supply the composed native renderer's module, not this branch's older
// normalized golden. No cloud credentials or Kubernetes cluster are needed.
func TestDedicatedCloudNativeReceiver(t *testing.T) {
	alloy, modulePath := os.Getenv("ALLOY_BINARY"), os.Getenv("CLOUD_METRICS_MODULE")
	if alloy == "" || modulePath == "" {
		t.Skip("set ALLOY_BINARY and CLOUD_METRICS_MODULE to run the native-cloud receiver regression")
	}
	module, err := os.ReadFile(modulePath)
	if err != nil {
		t.Fatal(err)
	}
	provider := os.Getenv("CLOUD_METRICS_PROVIDER")
	if provider == "" {
		provider = "aws"
	}
	type attribution struct{ installation, target, resource string }
	want := map[string]attribution{
		"aws_rds_cpuutilization_average": {"shop-orders-postgres", "orders", "arn:aws:rds:us-east-1:123456789012:db:shop-orders-pg"},
	}
	samples := `aws_rds_cpuutilization_average{dimension_DBInstanceIdentifier="shop-orders-pg",region="us-east-1",account_id="123456789012",test_case="admitted"} 12
aws_rds_cpuutilization_average{dimension_DBInstanceIdentifier="unadmitted",region="us-east-1",account_id="123456789012",test_case="unadmitted"} 34
aws_rds_cpuutilization_average{dimension_DBInstanceIdentifier="shop-orders-pg",region="eu-west-1",account_id="123456789012",test_case="wrong-region"} 56
aws_rds_cpuutilization_average{dimension_DBInstanceIdentifier="shop-orders-pg",region="us-east-1",account_id="999999999999",test_case="wrong-account"} 78
aws_rds_cpuutilization_average{dimension_DBInstanceIdentifier="shop-orders-pg",region="us-east-1",test_case="missing-account"} 90
`
	switch provider {
	case "gcp":
		want = map[string]attribution{
			"stackdriver_cloudsql_database_cloudsql_googleapis_com_database_cpu_utilization": {"shop-orders-postgres", "orders", "projects/prod-shop/instances/orders-pg"},
		}
		samples = `stackdriver_cloudsql_database_cloudsql_googleapis_com_database_cpu_utilization{database_id="prod-shop:orders-pg",test_case="admitted"} 12
stackdriver_cloudsql_database_cloudsql_googleapis_com_database_cpu_utilization{database_id="prod-shop:unadmitted",test_case="unadmitted"} 34
`
	case "azure":
		const redis = "/Subscriptions/3F7B2C1D-AAAA-4BBB-CCCC-000000000001/resourceGroups/shop-data/providers/Microsoft.Cache/Redis/sessions-cache"
		const managed = "/subscriptions/3f7b2c1d-aaaa-4bbb-cccc-000000000001/resourceGroups/shop-data/providers/Microsoft.Cache/redisEnterprise/amr-cart"
		want = map[string]attribution{
			"azure_microsoft_cache_redis_percentprocessortime_maximum_percent": {"shop-sessions-redis", "sessions", redis},
			"azure_microsoft_cache_redis_cachehits_total_count":                {"shop-sessions-redis", "sessions", redis},
		}
		samples = fmt.Sprintf(`azure_microsoft_cache_redis_percentprocessortime_maximum_percent{resourceID=%q,test_case="admitted"} 12
azure_microsoft_cache_redis_cachehits_total_count{resourceID=%q,test_case="admitted"} 12
azure_microsoft_cache_redis_cachehits_total_count{resourceID=%q,test_case="unadmitted"} 34
azure_microsoft_cache_redis_cachehits_total_count{resourceID=%q,test_case="child-resource"} 56
azure_microsoft_dbforpostgresql_flexibleservers_cpu_percent_average_percent{resourceID=%q,test_case="wrong-family"} 78
azure_microsoft_cache_redis_cachehits_total_count{test_case="unattributed"} 90
`, strings.ToLower(redis), strings.ToLower(redis), strings.ToLower(redis)+"-undeclared", strings.ToLower(redis)+"/databases/default", strings.ToLower(redis))
		for _, metric := range []string{
			"azure_microsoft_cache_redisenterprise_percentprocessortime_maximum_percent",
			"azure_microsoft_cache_redisenterprise_connectedclients_maximum_count",
			"azure_microsoft_cache_redisenterprise_cacheread_maximum_bytespersecond",
			"azure_microsoft_cache_redisenterprise_cachewrite_maximum_bytespersecond",
			"azure_microsoft_cache_redisenterprise_expiredkeys_total_count",
		} {
			want[metric+";0"] = attribution{"shop-cart-amr", "cart", managed}
			samples += fmt.Sprintf("%s{resourceID=%q,dimension=\"0\",test_case=\"admitted\"} 12\n", metric, strings.ToLower(managed))
		}
		const read = "azure_microsoft_cache_redisenterprise_cacheread_maximum_bytespersecond"
		want[read+";1"] = attribution{"shop-cart-amr", "cart", managed}
		samples += fmt.Sprintf("%s{resourceID=%q,dimension=\"1\",test_case=\"admitted\"} 12\n", read, strings.ToLower(managed))
		for _, resource := range []string{managed + "-undeclared", managed + "/databases/default", redis, ""} {
			samples += fmt.Sprintf("%s{resourceID=%q,dimension=\"0\",test_case=\"unadmitted-managed\"} 34\n", read, strings.ToLower(resource))
		}
		samples += fmt.Sprintf("azure_microsoft_cache_redis_cachehits_total_count{resourceID=%q,test_case=\"wrong-family\"} 56\n", strings.ToLower(managed))
	case "aws":
	default:
		t.Fatalf("unsupported test provider %q", provider)
	}
	samples += "go_goroutines{test_case=\"self\"} 7\nprocess_cpu_seconds_total{test_case=\"self\"} 8\nalloy_component_controller_health{test_case=\"self\"} 1\nryvn_unadmitted{test_case=\"self\"} 9\n"
	const a, b, offline = "11111111-1111-1111-1111-111111111111", "22222222-2222-2222-2222-222222222222", "33333333-3333-3333-3333-333333333333"
	for _, tc := range []struct{ name, selected, writer string }{
		{"default-a", a, "a"}, {"default-b", b, "b"}, {"pending", "", ""}, {"unavailable", offline, ""},
	} {
		t.Run(tc.name, func(t *testing.T) {
			var mu sync.Mutex
			var received []struct {
				path   string
				labels map[string]string
			}
			scrapes := 0
			server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				if r.URL.Path == "/metrics" {
					mu.Lock()
					scrapes++
					mu.Unlock()
					w.Header().Set("Content-Type", "text/plain; version=0.0.4")
					if _, err := fmt.Fprint(w, samples); err != nil {
						t.Error(err)
						return
					}
					return
				}
				if r.URL.Path == "/token" {
					w.Header().Set("Content-Type", "application/json")
					if _, err := fmt.Fprint(w, `{"access_token":"local-test","token_type":"Bearer","expires_in":3600}`); err != nil {
						t.Error(err)
						return
					}
					return
				}
				if r.Header.Get("X-Scope-OrgID") != "test-org" || r.Header.Get("X-Scope-EnvironmentName") != "test-cloud" || r.Header.Get("Authorization") != "Bearer local-test" {
					t.Error("remote-write tenant/auth headers were not preserved")
					http.Error(w, "invalid headers", 400)
					return
				}
				body, err := io.ReadAll(r.Body)
				if err != nil {
					http.Error(w, err.Error(), 400)
					return
				}
				decoded, err := snappy.Decode(nil, body)
				if err != nil {
					http.Error(w, err.Error(), 400)
					return
				}
				var request prompb.WriteRequest
				if err := request.Unmarshal(decoded); err != nil {
					http.Error(w, err.Error(), 400)
					return
				}
				mu.Lock()
				defer mu.Unlock()
				for _, series := range request.Timeseries {
					for _, sample := range series.Samples {
						if sample.Value != 12 {
							t.Errorf("sample value changed: %v", sample.Value)
						}
					}
					labels := map[string]string{}
					for _, label := range series.Labels {
						labels[label.Name] = label.Value
					}
					received = append(received, struct {
						path   string
						labels map[string]string
					}{r.URL.Path, labels})
				}
				w.WriteHeader(http.StatusNoContent)
			}))
			defer server.Close()
			values := dedicatedCloudValues(t, string(module), server.URL, provider)
			values["defaultConnectionId"] = tc.selected
			values["destinations"] = []map[string]any{
				{"connectionId": a, "name": "primary", "available": true, "metricsUrl": server.URL + "/a", "logsUrl": server.URL},
				{"connectionId": b, "name": "secondary", "available": true, "metricsUrl": server.URL + "/b", "logsUrl": server.URL},
				{"connectionId": offline, "name": "offline", "available": false, "unavailableReason": "test outage"},
			}
			data, err := yaml.Marshal(values)
			if err != nil {
				t.Fatal(err)
			}
			dir := t.TempDir()
			valuesPath := filepath.Join(dir, "values.yaml")
			if err := os.WriteFile(valuesPath, data, 0o600); err != nil {
				t.Fatal(err)
			}
			rendered, err := exec.Command("helm", "template", "dedicated-cloud", "..", "--namespace", "observability", "-f", valuesPath).CombinedOutput()
			if err != nil {
				t.Fatalf("helm template: %v\n%s", err, rendered)
			}
			config, renderedModule := dedicatedCloudConfig(t, rendered)
			// Only replace exporter/discovery I/O: keep the module's resource
			// admission, the chart's tail, UUID writers, tenant headers and OAuth.
			admission := alloyBlock(t, renderedModule, `prometheus.relabel "allowlist"`)
			admission = strings.ReplaceAll(admission, "argument.write_to.value", "[prometheus.relabel.cloud_metrics.receiver]")
			runtime := admission + "\n" + alloyBlock(t, config, `prometheus.relabel "cloud_metrics"`)
			for _, id := range []string{a, b} {
				runtime += "\n" + alloyBlock(t, config, `prometheus.remote_write "dest_`+strings.ReplaceAll(id, "-", "_")+`"`)
			}
			runtime += fmt.Sprintf("\nprometheus.scrape \"fixture\" {\n targets = [{\"__address__\" = %q}]\n scrape_interval = \"1s\"\n scrape_timeout = \"1s\"\n forward_to = [prometheus.relabel.allowlist.receiver]\n}\n", strings.TrimPrefix(server.URL, "http://"))
			configPath := filepath.Join(dir, "config.alloy")
			if err := os.WriteFile(configPath, []byte(runtime), 0o600); err != nil {
				t.Fatal(err)
			}
			if output, err := exec.Command(alloy, "validate", configPath).CombinedOutput(); err != nil {
				t.Fatalf("Alloy validate: %v\n%s", err, output)
			}
			log, err := os.Create(filepath.Join(dir, "alloy.log"))
			if err != nil {
				t.Fatal(err)
			}
			defer func() {
				if err := log.Close(); err != nil {
					t.Error(err)
					return
				}
			}()
			defer func() {
				if t.Failed() {
					data, err := os.ReadFile(log.Name())
					if err != nil {
						t.Error(err)
						return
					}
					t.Log(string(data))
				}
			}()
			listener, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			address := listener.Addr().String()
			if err := listener.Close(); err != nil {
				t.Fatal(err)
			}
			cmd := exec.Command(alloy, "run", "--server.http.listen-addr="+address, "--storage.path="+filepath.Join(dir, "storage"), configPath)
			cmd.Env = append(os.Environ(), "RYVN_CLIENT_ID=local-test", "RYVN_CLIENT_SECRET=local-test", "RYVN_TOKEN_URL="+server.URL+"/token")
			cmd.Stdout, cmd.Stderr = log, log
			if err := cmd.Start(); err != nil {
				t.Fatal(err)
			}
			defer func() {
				if err := cmd.Process.Signal(os.Interrupt); err != nil {
					t.Error(err)
					return
				}
				if err := cmd.Wait(); err != nil {
					t.Error(err)
					return
				}
			}()
			deadline := time.Now().Add(15 * time.Second)
			for time.Now().Before(deadline) {
				time.Sleep(100 * time.Millisecond)
				mu.Lock()
				ready := (tc.writer != "" && len(received) > 0) || (tc.writer == "" && scrapes >= 7)
				mu.Unlock()
				if ready {
					break
				}
			}
			mu.Lock()
			defer mu.Unlock()
			if scrapes < 2 {
				t.Fatalf("only %d scrapes; collection was not exercised", scrapes)
			}
			if tc.writer == "" {
				if len(received) != 0 {
					t.Fatalf("pending/unavailable default leaked %d series", len(received))
				}
				return
			}
			if len(received) == 0 {
				t.Fatal("admitted native metric never reached the selected UUID writer")
			}
			seen := map[string]bool{}
			for _, series := range received {
				metric := series.labels["__name__"]
				key := metric
				if instance := series.labels["dimension"]; instance != "" {
					key += ";" + instance
				}
				expected, ok := want[key]
				if !ok || series.path != "/"+tc.writer+"/api/v1/push" || series.labels["test_case"] != "admitted" || series.labels["environment"] != "test-cloud" || series.labels["installation"] != expected.installation || series.labels["cloud_target"] != expected.target || series.labels["cloud_resource_id"] != expected.resource || series.labels["__cloud_dim"] != "" {
					t.Fatalf("unexpected delivery: %s %v", series.path, series.labels)
				}
				seen[key] = true
			}
			for metric := range want {
				if !seen[metric] {
					t.Errorf("admitted native metric %s never reached the selected UUID writer", metric)
				}
			}
		})
	}
}

func dedicatedCloudConfig(t *testing.T, rendered []byte) (config, module string) {
	t.Helper()
	decoder := yaml.NewDecoder(bytes.NewReader(rendered))
	var mainConfigMap, moduleConfigMap, serviceAccount string
	var mounted []string
	accounts := map[string]bool{}
	collectors := 0
	for {
		var doc struct {
			Kind     string
			Metadata struct {
				Name   string
				Labels map[string]string
			}
			Data map[string]string
			Spec struct {
				Replicas int
				Template struct {
					Spec struct {
						ServiceAccountName string `yaml:"serviceAccountName"`
						Volumes            []struct {
							ConfigMap struct{ Name string } `yaml:"configMap"`
						}
					}
				}
			}
		}
		if err := decoder.Decode(&doc); errors.Is(err, io.EOF) {
			break
		} else if err != nil {
			t.Fatal(err)
		}
		switch doc.Kind {
		case "ConfigMap":
			if strings.Contains(doc.Data["config.alloy"], `prometheus.relabel "cloud_metrics"`) {
				config, mainConfigMap = doc.Data["config.alloy"], doc.Metadata.Name
			} else if strings.Contains(doc.Data["config.alloy"], `declare "pipeline"`) {
				module, moduleConfigMap = doc.Data["config.alloy"], doc.Metadata.Name
			}
		case "ServiceAccount":
			accounts[doc.Metadata.Name] = true
		case "Deployment", "DaemonSet", "StatefulSet":
			if doc.Metadata.Labels["app.kubernetes.io/name"] != "alloy" {
				continue
			}
			collectors++
			if doc.Kind != "Deployment" || doc.Spec.Replicas != 1 {
				t.Fatalf("dedicated collector must be a singleton Deployment: %s replicas=%d", doc.Kind, doc.Spec.Replicas)
			}
			serviceAccount = doc.Spec.Template.Spec.ServiceAccountName
			for _, volume := range doc.Spec.Template.Spec.Volumes {
				mounted = append(mounted, volume.ConfigMap.Name)
			}
		}
	}
	if collectors != 1 || serviceAccount == "" || !accounts[serviceAccount] {
		t.Fatalf("expected one collector with its own ServiceAccount: collectors=%d account=%q", collectors, serviceAccount)
	}
	if mainConfigMap == "" || mainConfigMap == "ryvn-alloy-config" || moduleConfigMap != "dedicated-cloud-ryvn-collector-cloud-metrics" || !strings.Contains(alloyBlock(t, config, `remote.kubernetes.configmap "cloud_metrics"`), `"`+moduleConfigMap+`"`) {
		t.Fatalf("dedicated main/module ConfigMap identity lost: main=%q module=%q", mainConfigMap, moduleConfigMap)
	}
	if !slices.Contains(mounted, mainConfigMap) {
		t.Fatalf("dedicated main ConfigMap %q not mounted in %v", mainConfigMap, mounted)
	}
	for _, platform := range []string{`discovery.kubernetes "pod"`, `prometheus.scrape "cadvisor"`, `prometheus.scrape "kubelet"`, `prometheus.scrape "prometheus_metrics"`, `prometheus.scrape "kube_state_metrics"`, `loki.source.kubernetes_events`, `loki.source.kubernetes`, `loki.write `} {
		if strings.Contains(config, platform) {
			t.Fatalf("platform pipeline enabled in dedicated cloud collector: %s", platform)
		}
	}
	return config, module
}

func dedicatedCloudValues(t *testing.T, module, endpoint, provider string) map[string]any {
	t.Helper()
	path := os.Getenv("CLOUD_METRICS_BLUEPRINT")
	if path == "" {
		path = "../../../ryvn-iac/blueprints/cloud-metrics.blueprint.yaml"
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var blueprint struct {
		Spec struct {
			Installations []struct{ Service, Alias, Config string }
		}
	}
	if err := yaml.Unmarshal(data, &blueprint); err != nil {
		t.Fatal(err)
	}
	for _, installation := range blueprint.Spec.Installations {
		if installation.Service != "ryvn-collector" || installation.Alias != provider+"-collector" {
			continue
		}
		functions := sprig.TxtFuncMap()
		functions["k8sSecretName"] = func(s string) string { return s }
		functions["serviceInstallation"] = func(name string) (map[string]any, error) {
			if provider != "azure" || name != "azure-identity" {
				return nil, fmt.Errorf("unexpected identity fixture %q for %s", name, provider)
			}
			return map[string]any{"outputs": map[string]any{
				"client_ids": map[string]string{"cloud_metrics": "44444444-4444-4444-4444-444444444444"},
				"tenant_id":  "55555555-5555-5555-5555-555555555555",
			}}, nil
		}
		functions["input"] = func(name string) any {
			if name == "configAlloy" {
				return module
			}
			return ""
		}
		functions["toYaml"] = func(value any) (string, error) {
			data, err := yaml.Marshal(value)
			return strings.TrimSuffix(string(data), "\n"), err
		}
		functions["Hub"] = func(name string) string {
			if name == "tokenUrl" {
				return endpoint + "/token"
			}
			return endpoint
		}
		tmpl, err := template.New("collector").Funcs(functions).Parse(installation.Config)
		if err != nil {
			t.Fatal(err)
		}
		var rendered bytes.Buffer
		if err := tmpl.Execute(&rendered, map[string]any{"ryvn": map[string]any{"env": map[string]any{"name": "test-cloud", "orgId": "test-org"}}}); err != nil {
			t.Fatal(err)
		}
		var values map[string]any
		if err := yaml.Unmarshal(rendered.Bytes(), &values); err != nil {
			t.Fatal(err)
		}
		return values
	}
	t.Fatal("dedicated cloud blueprint has no collector child")
	return nil
}

func alloyBlock(t *testing.T, config, component string) string {
	t.Helper()
	start := strings.Index(config, component+" {")
	if start < 0 {
		t.Fatalf("missing %s", component)
	}
	// JSON string decoding skips braces in quoted Alloy strings.
	depth := 0
	for i := start + len(component); i < len(config); i++ {
		switch config[i] {
		case '"':
			var s string
			d := json.NewDecoder(strings.NewReader(config[i:]))
			if err := d.Decode(&s); err != nil {
				t.Fatal(err)
			}
			i += int(d.InputOffset()) - 1
		case '{':
			depth++
		case '}':
			depth--
			if depth == 0 {
				return config[start : i+1]
			}
		}
	}
	t.Fatalf("unterminated %s", component)
	return ""
}
