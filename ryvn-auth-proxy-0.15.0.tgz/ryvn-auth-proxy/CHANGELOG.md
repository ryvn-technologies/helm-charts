# Changelog

## 0.3.0

### Changed

* Chart renamed from `auth-proxy` to `ryvn-auth-proxy` and published to `oci://registry-1.docker.io/ryvn/ryvn-auth-proxy` in addition to `charts.ryvn.app`; `nameOverride` defaults to `auth-proxy` so rendered resource names are unchanged for existing releases
* `image.repository` defaults to the public Docker Hub image `ryvn/auth-proxy` (multi-arch) instead of Ryvn's private ECR; set it back to `703671917981.dkr.ecr.us-east-1.amazonaws.com/ryvn/auth-proxy` to keep pulling from ECR

## 0.2.1

### Changed

* `RYVN_DATASOURCE_SUBJECT_ID` is optional in hub mode; the datasource subject defaults to the `userId` of the `RYVN_HUB_SERVICE_ACCOUNT_FILE` key

## 0.2.0

### Added

* JWT-only token verification and datasource gateway identity settings
* optional hub hosting environment authorization for telemetry ingest
