# Changelog

## [0.9.5](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.9.4...ryvn-collector@v0.9.5) (2026-01-13)


### Bug Fixes

* use just annotations ([#3796](https://github.com/ryvn-technologies/ryvn/issues/3796)) ([a66f19b](https://github.com/ryvn-technologies/ryvn/commit/a66f19b20a9378a27e128766026cede7df059156))

## [0.9.4](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.9.3...ryvn-collector@v0.9.4) (2026-01-12)


### Bug Fixes

* Revert "fix: drop invalid targets for scraping" ([#3772](https://github.com/ryvn-technologies/ryvn/issues/3772)) ([6ec4f4f](https://github.com/ryvn-technologies/ryvn/commit/6ec4f4f4b0686c009e6462c2b3111befb467690a))

## [0.9.3](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.9.2...ryvn-collector@v0.9.3) (2026-01-09)


### Bug Fixes

* drop invalid targets for scraping ([#3729](https://github.com/ryvn-technologies/ryvn/issues/3729)) ([c4220b8](https://github.com/ryvn-technologies/ryvn/commit/c4220b8aa3a06e13cd97e4de28a226cbb3172c2d))

## [0.9.2](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.9.1...ryvn-collector@v0.9.2) (2025-12-13)


### Bug Fixes

* move to annotation ([c7e325c](https://github.com/ryvn-technologies/ryvn/commit/c7e325c76d718df5ecd6c5a012975f2ea80c8f82))

## [0.9.1](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.9.0...ryvn-collector@v0.9.1) (2025-12-13)


### Bug Fixes

* metrics path ([a8c5939](https://github.com/ryvn-technologies/ryvn/commit/a8c59390aaa51b4055b6678d679dd711f0c84e6d))

## [0.9.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.8.5...ryvn-collector@v0.9.0) (2025-12-13)


### Features

* allow service monitors ([4f16237](https://github.com/ryvn-technologies/ryvn/commit/4f16237800ad8c2b4641ad83740d92db95538761))

## [0.8.5](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.8.4...ryvn-collector@v0.8.5) (2025-12-01)


### Bug Fixes

* enable clustering for kube_state_metrics scrape ([dc889b8](https://github.com/ryvn-technologies/ryvn/commit/dc889b880799b18f1fbe2ee3d05e6c87d3438186))

## [0.8.4](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.8.3...ryvn-collector@v0.8.4) (2025-10-06)


### Bug Fixes

* add allow list for cadvisor metrics, filter out noise ([#2818](https://github.com/ryvn-technologies/ryvn/issues/2818)) ([eaded07](https://github.com/ryvn-technologies/ryvn/commit/eaded07a736641b67531ab2030c7356d58fb4617))

## [0.8.3](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.8.2...ryvn-collector@v0.8.3) (2025-10-06)


### Bug Fixes

* metrics flag on collector ([#2815](https://github.com/ryvn-technologies/ryvn/issues/2815)) ([bf052d5](https://github.com/ryvn-technologies/ryvn/commit/bf052d5bf9087f148250557348ffabefa7ad261d))

## [0.8.2](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.8.1...ryvn-collector@v0.8.2) (2025-08-19)


### Bug Fixes

* add toleration to collector ([#2412](https://github.com/ryvn-technologies/ryvn/issues/2412)) ([2f012f9](https://github.com/ryvn-technologies/ryvn/commit/2f012f9918e8d1c239781860ba2f91f4a1b591da))

## [0.8.1](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.8.0...ryvn-collector@v0.8.1) (2025-08-15)


### Bug Fixes

* scrape k8s events as logs ([#2368](https://github.com/ryvn-technologies/ryvn/issues/2368)) ([e1974ce](https://github.com/ryvn-technologies/ryvn/commit/e1974ce0525df7c51009ddf91a705b87ddf13d10))

## [0.8.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.7.2...ryvn-collector@v0.8.0) (2025-06-25)


### Features

* **collector:** add kube-state-metrics ([#1976](https://github.com/ryvn-technologies/ryvn/issues/1976)) ([ba7e323](https://github.com/ryvn-technologies/ryvn/commit/ba7e323748d73bddea3990a1dd8e1174838722fd))

## [0.7.2](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.7.1...ryvn-collector@v0.7.2) (2025-06-17)


### Bug Fixes

* filter out failed pods ([#1893](https://github.com/ryvn-technologies/ryvn/issues/1893)) ([457f6da](https://github.com/ryvn-technologies/ryvn/commit/457f6da7a94dfea40e3add54266c1e379842c80a))

## [0.7.1](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.7.0...ryvn-collector@v0.7.1) (2025-05-20)


### Bug Fixes

* replacement ([#1663](https://github.com/ryvn-technologies/ryvn/issues/1663)) ([2faec31](https://github.com/ryvn-technologies/ryvn/commit/2faec31d73b8579f923d743285222e3e20887a54))

## [0.7.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.6.0...ryvn-collector@v0.7.0) (2025-05-20)


### Features

* regex redaction ([#1659](https://github.com/ryvn-technologies/ryvn/issues/1659)) ([514d46c](https://github.com/ryvn-technologies/ryvn/commit/514d46ca1546e1058466e5efe3be30db7c154987))

## [0.6.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.5.0...ryvn-collector@v0.6.0) (2025-04-20)


### Features

* scrape request metrics ([#1267](https://github.com/ryvn-technologies/ryvn/issues/1267)) ([5ebc554](https://github.com/ryvn-technologies/ryvn/commit/5ebc5546a6ea7d2ff810c654c6f08bc23b5539bb))

## [0.5.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.4.0...ryvn-collector@v0.5.0) (2025-04-20)


### Features

* allow additional arbitrary conf ([#1257](https://github.com/ryvn-technologies/ryvn/issues/1257)) ([6fa406a](https://github.com/ryvn-technologies/ryvn/commit/6fa406ad0abfe3929593832a7688bd1b8ff25d60))

## [0.4.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.3.0...ryvn-collector@v0.4.0) (2025-04-20)


### Features

* feature flag pod logs ([#1253](https://github.com/ryvn-technologies/ryvn/issues/1253)) ([7b8a6cc](https://github.com/ryvn-technologies/ryvn/commit/7b8a6cc34eef7ed6dc37245819b392aabf60894b))

## [0.3.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.2.0...ryvn-collector@v0.3.0) (2025-04-20)


### Features

* uninstall by install id ([#1250](https://github.com/ryvn-technologies/ryvn/issues/1250)) ([c167eba](https://github.com/ryvn-technologies/ryvn/commit/c167ebaabdb96f2a35e98eae36de41aca641c87e))

## [0.2.0](https://github.com/ryvn-technologies/ryvn/compare/ryvn-collector@v0.1.0...ryvn-collector@v0.2.0) (2025-04-19)


### Features

* add collector chart ([#1245](https://github.com/ryvn-technologies/ryvn/issues/1245)) ([bcff0ec](https://github.com/ryvn-technologies/ryvn/commit/bcff0ec0fcb4af65248b9603fa724d41e09b020c))
