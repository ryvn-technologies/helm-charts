{{/*
Expand the name of the chart.
*/}}
{{- define "ryvn-collector.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ryvn-collector.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ryvn-collector.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ryvn-collector.labels" -}}
helm.sh/chart: {{ include "ryvn-collector.chart" . }}
{{ include "ryvn-collector.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Alloy component label for a destination, derived from its connection ID so it
is unique by construction. UUIDs contain "-", which Alloy identifiers cannot,
so it becomes "_" and the result is prefixed to keep it distinct from built-in
components.
*/}}
{{- define "ryvn-collector.destinationId" -}}
{{- printf "dest_%s" (. | toString | replace "-" "_") -}}
{{- end }}

{{/*
Prometheus meta-label suffix of the destination label key, as
discovery.kubernetes exposes it (every character outside [A-Za-z0-9_] becomes "_").
*/}}
{{- define "ryvn-collector.destinationLabelMeta" -}}
{{- regexReplaceAll "[^A-Za-z0-9_]" .Values.destinationLabel "_" -}}
{{- end }}

{{/*
Regex literal (escaped for an Alloy string) matching exactly one destination name.
*/}}
{{- define "ryvn-collector.destinationNameRegex" -}}
{{- regexQuoteMeta . | replace "\\" "\\\\" -}}
{{- end }}

{{/*
Regex literal (escaped for an Alloy string) matching every configured destination name.
*/}}
{{- define "ryvn-collector.destinationNamesRegex" -}}
{{- $names := list -}}
{{- range .Values.destinations -}}
{{- $names = append $names (include "ryvn-collector.destinationNameRegex" .name) -}}
{{- end -}}
{{- join "|" $names -}}
{{- end }}

{{/*
Rejects destinations the chart cannot render: names that are not label values
(and so could never be selected), connection IDs that do not form a component
label, and URLs that are missing, not http(s), or contain characters that
would escape the Alloy string they are rendered into.
*/}}
{{- define "ryvn-collector.validateDestinations" -}}
{{- range .Values.destinations -}}
{{- $name := .name | toString -}}
{{- if not (regexMatch "^[A-Za-z0-9]([-A-Za-z0-9_.]{0,61}[A-Za-z0-9])?$" $name) -}}
{{- fail (printf "destination name %q is not a valid Kubernetes label value" $name) -}}
{{- end -}}
{{- if not (regexMatch "^[A-Za-z0-9_-]+$" (.connectionId | default "" | toString)) -}}
{{- fail (printf "destination %q needs a connectionId" $name) -}}
{{- end -}}
{{- if not (regexMatch "^https?://[^\"\\\\\\s]+$" (.logsUrl | default "" | toString)) -}}
{{- fail (printf "destination %q needs an http(s) logsUrl" $name) -}}
{{- end -}}
{{- if not (regexMatch "^https?://[^\"\\\\\\s]+$" (.metricsUrl | default "" | toString)) -}}
{{- fail (printf "destination %q needs an http(s) metricsUrl" $name) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
OAuth2 client-credentials block shared by every Loki and Mimir writer,
indented for an endpoint block.
*/}}
{{- define "ryvn-collector.oauth2" }}
        oauth2 {
          client_id = sys.env("RYVN_CLIENT_ID")
          client_secret = sys.env("RYVN_CLIENT_SECRET")
          scopes = ["openid","email","roles","profile","offline_access","urn:zitadel:iam:user:resourceowner","urn:zitadel:iam:org:project:id:zitadel:aud","urn:zitadel:iam:org:project:id:" + coalesce(sys.env("RYVN_PROJECT_ID"), "{{ .Values.auth.projectId }}") + ":aud"]
          token_url = coalesce(sys.env("RYVN_TOKEN_URL"), "{{ .Values.auth.tokenUrl }}")
        }
{{- end }}

{{/*
Relabel rules shared by the hub and per-destination pod log discovery,
indented for a discovery.relabel block.
*/}}
{{- define "ryvn-collector.podLogsRelabelRules" -}}
      {{- if not .Values.features.podLogs.collectUserLogs }}
      // Keep system namespace logs while dropping user workload logs in-cluster
      rule {
        source_labels = ["__meta_kubernetes_namespace"]
        regex = "^({{ .Values.features.podLogs.systemNamespaces | join "|" }})$"
        action = "keep"
      }

      {{- end }}
      // Label creation - "namespace" field from "__meta_kubernetes_namespace"
      rule {
        source_labels = ["__meta_kubernetes_namespace"]
        action = "replace"
        target_label = "namespace"
      }

      // Label creation - "pod" field from "__meta_kubernetes_pod_name"
      rule {
        source_labels = ["__meta_kubernetes_pod_name"]
        action = "replace"
        target_label = "pod"
      }

      // Label creation - "container" field from "__meta_kubernetes_pod_container_name"
      rule {
        source_labels = ["__meta_kubernetes_pod_container_name"]
        action = "replace"
        target_label = "container"
      }

      // Label creation -  "service" field from "__meta_kubernetes_pod_label_app_kubernetes_io_instance"
      rule {
        source_labels = ["__meta_kubernetes_pod_label_app_kubernetes_io_instance"]
        action = "replace"
        target_label = "service"
      }

      // Service name from ryvn.app/service-name label should take precedence if it exists
      rule {
        source_labels = ["__meta_kubernetes_pod_label_ryvn_app_service_name"]
        regex = "(.+)"  // Only if the label exists and is non-empty
        action = "replace"
        target_label = "service"
      }

      // Label creation -  "version" field from "__meta_kubernetes_pod_label_app_kubernetes_io_version"
      rule {
        source_labels = ["__meta_kubernetes_pod_label_app_kubernetes_io_version"]
        action = "replace"
        target_label = "version"
      }

      // Add environment name
      rule {
        replacement = "{{ .Values.environment.name }}"
        target_label = "environment"
        action = "replace"
      }

      // Installation name from instance label (fallback)
      rule {
        source_labels = ["__meta_kubernetes_pod_label_app_kubernetes_io_instance"]
        action = "replace"
        target_label = "installation"
      }

      // ryvn.app/installation-name takes precedence if present (injected for web-server/job types)
      rule {
        source_labels = ["__meta_kubernetes_pod_label_ryvn_app_installation_name"]
        regex = "(.+)"
        action = "replace"
        target_label = "installation"
      }


      // Keep the following rules to avoid high-cardinality in label values

      // Label creation - "container" field from "__meta_kubernetes_pod_uid" and "__meta_kubernetes_pod_container_name"
      // Concatenate values __meta_kubernetes_pod_uid/__meta_kubernetes_pod_container_name.log
      rule {
        source_labels = ["__meta_kubernetes_pod_uid", "__meta_kubernetes_pod_container_name"]
        action = "replace"
        target_label = "__path__"
        separator = "/"
        replacement = "/var/log/pods/*$1/*.log"
      }

      // Label creation -  "container_runtime" field from "__meta_kubernetes_pod_container_id"
      rule {
        source_labels = ["__meta_kubernetes_pod_container_id"]
        action = "replace"
        target_label = "container_runtime"
        regex = "^(\\S+):\\/\\/.+$"
        replacement = "$1"
      }
{{- end }}

{{/*
Filter and redaction stages between a pod log source and its writer. Takes a
dict with root (chart context), suffix (component label suffix, empty for the
hub route) and writer (loki.write component reference).
*/}}
{{- define "ryvn-collector.lokiProcessChain" -}}
{{- $root := .root }}{{- $suffix := .suffix }}

    loki.process "pod_log_filter{{ $suffix }}" {
      // Drop noisy collector errors from terminating containers
      stage.drop {
        expression = "unable to retrieve container logs"
        drop_counter_reason = "alloy_container_teardown"
      }
      {{- if $root.Values.features.logRedaction.enabled }}
      forward_to = [loki.process.redact{{ $suffix }}.receiver]
    }

    loki.process "redact{{ $suffix }}" {
      forward_to = [{{ .writer }}.receiver]
      {{- range $root.Values.features.logRedaction.patterns }}
      stage.replace {
        expression = "{{ . }}"
        replace = "{{ $root.Values.features.logRedaction.replacement }}"
      }
      {{- end }}
    }
    {{- else }}
      forward_to = [{{ .writer }}.receiver]
    }
    {{- end }}
{{- end }}

{{/*
Target relabel rules shared by the hub and per-destination annotated endpoint
discovery, indented for a discovery.relabel block.
*/}}
{{- define "ryvn-collector.prometheusMetricsRelabelRules" }}

      // Keep only endpoints with ryvn.app scrape annotation enabled
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_scrape_metrics"]
        regex = "true"
        action = "keep"
      }

      // Keep only ready endpoints
      rule {
        source_labels = ["__meta_kubernetes_endpoint_ready"]
        regex = "true"
        action = "keep"
      }

      // Set the port from ryvn.app/metrics-port annotation
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_metrics_port"]
        regex = "(.+)"
        action = "replace"
        target_label = "__meta_kubernetes_endpoint_port_name"
        replacement = "${1}"
      }

      // only keep targets where the pod is running or the pod_phase is empty and is not an init container.  This will only exist for role="pod" or
      // potentially role="endpoints", if it is a service the value is empty and thus allowed to pass, if it is an endpoint but not associated to a
      // pod but rather a static IP or hostname, that could be outside of kubernetes allow endpoints to declare what tenant their metrics should be
      // written to
      rule {
        action = "keep"
        source_labels = ["__meta_kubernetes_pod_phase"]
        regex = "^(?i)(Running|)$"
      }
      rule {
        action = "keep"
        source_labels = ["__meta_kubernetes_pod_ready"]
        regex = "^(true|)$"
      }
      // if the container is an init container, drop it
      rule {
        action = "drop"
        source_labels = ["__meta_kubernetes_pod_container_init"]
        regex = "^(true)$"
      }
      // Set the address using endpoint hostname and port
      rule {
        source_labels = ["__meta_kubernetes_endpoint_hostname", "__meta_kubernetes_service_annotation_ryvn_app_metrics_port"]
        separator = ";"
        regex = "([^;]+);(.+)"
        replacement = "${1}:${2}"
        target_label = "__address__"
        action = "replace"
      }

      // Set custom metrics path from ryvn.app/metrics-path annotation (defaults to /metrics if not set)
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_metrics_path"]
        regex = "(.+)"
        action = "replace"
        target_label = "__metrics_path__"
      }

      // Set a per-target scrape interval from ryvn.app/scrape-interval (defaults
      // to the prometheus.scrape interval below). Slow-moving targets such as
      // database exporters can trade resolution for ingest volume.
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_scrape_interval"]
        regex = "(.+)"
        action = "replace"
        target_label = "__scrape_interval__"
      }

      // A target's timeout may not exceed its interval, so a custom interval
      // carries the timeout with it. The two rules are ordered so an explicit
      // ryvn.app/scrape-timeout wins over that derived value.
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_scrape_interval"]
        regex = "(.+)"
        action = "replace"
        target_label = "__scrape_timeout__"
      }
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_scrape_timeout"]
        regex = "(.+)"
        action = "replace"
        target_label = "__scrape_timeout__"
      }

      // Add standard labels
      rule {
        source_labels = ["__meta_kubernetes_namespace"]
        action = "replace"
        target_label = "namespace"
      }

      // Set service name from app.kubernetes.io/name label
      rule {
        source_labels = ["__meta_kubernetes_endpoints_label_app_kubernetes_io_name"]
        action = "replace"
        target_label = "service"
      }

      // Set installation name from app.kubernetes.io/instance label
      rule {
        source_labels = ["__meta_kubernetes_endpoints_label_app_kubernetes_io_instance"]
        action = "replace"
        target_label = "installation"
      }

      // ryvn.app/installation-name takes precedence if present, so an exporter
      // deployed alongside a resource can attribute its metrics to that
      // resource's installation rather than to its own release
      rule {
        source_labels = ["__meta_kubernetes_endpoints_label_ryvn_app_installation_name"]
        regex = "(.+)"
        action = "replace"
        target_label = "installation"
      }

      // Targets opt into having their runtime metrics dropped with
      // ryvn.app/drop-runtime-metrics: "true". Carried as a real label because
      // __-prefixed labels never reach the metric relabel stage; it is dropped
      // again there, so it is not remote written.
      rule {
        source_labels = ["__meta_kubernetes_service_annotation_ryvn_app_drop_runtime_metrics"]
        regex = "(true)"
        action = "replace"
        target_label = "ryvn_drop_runtime_metrics"
      }

      rule {
        source_labels = ["__meta_kubernetes_endpoint_address_target_kind"]
        regex = "Pod"
        action = "replace"
        target_label = "target_kind"
      }

      rule {
        source_labels = ["__meta_kubernetes_endpoint_address_target_name"]
        action = "replace"
        target_label = "pod"
      }

      // Add environment name
      rule {
        replacement = "{{ .Values.environment.name }}"
        target_label = "environment"
        action = "replace"
      }

      // Add source label
      rule {
        replacement = "kubernetes"
        target_label = "source"
      }
{{- end }}

{{/*
Metric relabel rules shared by the hub and per-destination annotated endpoint
scrapes, indented for a prometheus.relabel block.
*/}}
{{- define "ryvn-collector.prometheusMetricsMetricRules" -}}

      {{- with .Values.features.metrics.dropMetricNameRegex }}
      // Drop runtime metrics from targets that opted in. They say nothing about
      // the workload an exporter reports on and are the same for every exporter,
      // but they are real signal for a service scraping itself, so this is never
      // applied to a target that did not ask for it.
      rule {
        source_labels = ["__name__", "ryvn_drop_runtime_metrics"]
        separator = ";"
        regex = {{ printf "(?:%s);true" (trimSuffix "$" (trimPrefix "^" .)) | quote }}
        action = "drop"
      }
      {{- end }}

      {{- with .Values.features.metrics.dropSettingsMetricNameRegex }}
      // Postgres server settings are one series per setting and never change
      // between scrapes, so only the ones we chart are kept. A drop rule cannot
      // express "every name but these", so candidacy and exemption are marked
      // separately and the drop keys on the pair. Each configured regex is
      // matched against __name__ on its own, so anchors behave as written.
      rule {
        source_labels = ["__name__"]
        regex = {{ . | quote }}
        replacement = "true"
        action = "replace"
        target_label = "ryvn_drop_setting"
      }
      {{- range $.Values.features.metrics.keepSettingsMetricNames }}
      rule {
        source_labels = ["__name__"]
        regex = {{ . | quote }}
        replacement = "true"
        action = "replace"
        target_label = "ryvn_keep_setting"
      }
      {{- end }}
      rule {
        source_labels = ["ryvn_drop_setting", "ryvn_keep_setting"]
        separator = ";"
        regex = "true;"
        action = "drop"
      }
      rule {
        regex = "ryvn_(drop|keep)_setting"
        action = "labeldrop"
      }
      {{- end }}

      rule {
        regex = "ryvn_drop_runtime_metrics"
        action = "labeldrop"
      }
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ryvn-collector.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-collector.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}
