# ryvn-collector

Wraps Grafana Alloy to ship logs, Kubernetes events and Prometheus metrics from a
customer environment to Ryvn's Loki and Mimir, tenanted by organization.

## Scraping a workload's own exporter

Alloy discovers Services annotated for scraping. Annotations live on the
Service; labels used for attribution live on its Endpoints.

| Annotation | Effect |
| --- | --- |
| `ryvn.app/scrape-metrics: "true"` | Required. Opts the Service's ready endpoints into scraping. |
| `ryvn.app/metrics-port` | Port number to scrape. Used verbatim in the target address, so a port *name* does not work. |
| `ryvn.app/metrics-path` | Metrics path; defaults to `/metrics`. |
| `ryvn.app/scrape-interval` | Per-target interval, overriding the chart default. Also lowers the timeout, since a timeout may not exceed its interval. |
| `ryvn.app/scrape-timeout` | Per-target timeout; wins over the value derived from the interval. |
| `ryvn.app/drop-runtime-metrics: "true"` | Drops the exporter's own `go_*`, `process_*` and `promhttp_*` series (`features.metrics.dropMetricNameRegex`). |

| Label | Effect |
| --- | --- |
| `app.kubernetes.io/instance` | Default value of the `installation` label. |
| `ryvn.app/installation-name` | Overrides `installation`, so an exporter deployed beside a resource attributes its series to that resource's installation rather than to the exporter's own release. |
| `app.kubernetes.io/name` | Value of the `service` label. |

Every metric also carries `environment`; the organization is the Mimir tenant
(`X-Scope-OrgID`), not a label. Scoping a query by namespace alone is not
enough: installations in an environment share a namespace, so use `environment`
plus `installation`.

`features.metrics.keepSettingsMetricNames` and `dropSettingsMetricNameRegex`
trim high-cardinality, never-changing series (postgres-exporter reports one
series per server setting); the named metrics survive the drop.

## Releases

Merging a change to this chart does not release it. The release workflow
(`.github/workflows/ryvn-collector-release.yaml`) fires on PR close and only
when the merged PR carries the `auto-release:ryvn-collector` label, so a PR
merged without it ships nothing. CI generates the release version and rewrites
`Chart.yaml`; the version committed here is not what gets published.

Customer environments subscribe to the `stable` channel through the platform
blueprints, so a new release also has to be promoted into `stable` (and
`production` for Ryvn's own environments) before any environment picks it up.
