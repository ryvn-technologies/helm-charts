{{/*
Expand the name of the chart.
*/}}
{{- define "chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "chart.labels" -}}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name
*/}}
{{- define "chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "chart.fullname" . -}}
{{- end -}}
{{- end }}

{{/*
Resolve provisioner config values while remaining compatible with the
existing bootstrap config payload stored on the installation.
*/}}
{{- define "chart.provisioner.apiUrl" -}}
{{- coalesce .Values.config.apiUrl .Values.API_URL -}}
{{- end }}

{{- define "chart.provisioner.authUrl" -}}
{{- coalesce .Values.config.authUrl .Values.AUTH_URL -}}
{{- end }}

{{- define "chart.provisioner.projectId" -}}
{{- coalesce .Values.config.projectId .Values.PROJECT_ID -}}
{{- end }}

{{- define "chart.provisioner.environment" -}}
{{- coalesce .Values.config.environment .Values.ENVIRONMENT -}}
{{- end }}

{{- define "chart.provisioner.orgId" -}}
{{- $legacy := default "" (index .Values "current-org-id") -}}
{{- coalesce .Values.config.orgId $legacy -}}
{{- end }}
