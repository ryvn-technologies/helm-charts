{{- define "ryvn-net.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ryvn-net.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "ryvn-net.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Suffixed names truncate the base so the full name stays within the 63-char
object-name limit even for long release names: "-metrics" is 8 chars,
"-leader-election" is 16.
*/}}
{{- define "ryvn-net.metricsName" -}}
{{- printf "%s-metrics" (include "ryvn-net.fullname" . | trunc 55 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.leaderElectionName" -}}
{{- printf "%s-leader-election" (include "ryvn-net.fullname" . | trunc 47 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.labels" -}}
helm.sh/chart: {{ include "ryvn-net.chart" . }}
{{ include "ryvn-net.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: networking-operator
{{- end }}

{{- define "ryvn-net.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-net.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "ryvn-net.serviceAccountName" -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "ryvn-net.fullname" . -}}
{{- end -}}
{{- end }}

{{- define "ryvn-net.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{ printf "%s:%s" .Values.image.repository $tag }}
{{- end }}
