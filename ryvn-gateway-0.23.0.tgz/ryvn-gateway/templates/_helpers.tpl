{{/*
Expand the name of the chart.
*/}}
{{- define "ryvn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ryvn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ryvn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create the metrics Service name.
*/}}
{{- define "ryvn-gateway.metricsServiceName" -}}
{{- printf "%s-gw-metrics" (include "ryvn-gateway.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create the API readiness hook resource name.
*/}}
{{- define "ryvn-gateway.apiReadinessHookName" -}}
{{- printf "%s-api-readiness" (include "ryvn-gateway.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the ServiceAccount name used by the API readiness hook.
*/}}
{{- define "ryvn-gateway.apiReadinessServiceAccountName" -}}
{{- $apiReadiness := .Values.apiReadiness | default (dict) -}}
{{- $serviceAccount := $apiReadiness.serviceAccount | default (dict) -}}
{{- if (ternary $serviceAccount.create true (hasKey $serviceAccount "create")) -}}
{{- default (include "ryvn-gateway.apiReadinessHookName" .) $serviceAccount.name -}}
{{- else -}}
{{- default "default" $serviceAccount.name -}}
{{- end -}}
{{- end }}

{{/*
Create the cluster-scoped RBAC resource name used by the API readiness hook.
*/}}
{{- define "ryvn-gateway.apiReadinessClusterRoleName" -}}
{{- printf "%s-%s" (include "ryvn-gateway.apiReadinessHookName" .) (.Release.Namespace | sha256sum | trunc 8) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the metrics Telemetry resource name.
*/}}
{{- define "ryvn-gateway.metricsTelemetryName" -}}
{{- printf "%s-gw-metrics-telemetry" (include "ryvn-gateway.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ryvn-gateway.labels" -}}
helm.sh/chart: {{ include "ryvn-gateway.chart" . }}
{{ include "ryvn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ryvn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Istio labels generated Gateway data-plane pods with the Gateway name.
*/}}
{{- define "ryvn-gateway.gatewayPodSelectorLabels" -}}
gateway.networking.k8s.io/gateway-name: {{ include "ryvn-gateway.fullname" . }}
{{- end }}

{{/*
Resolve and validate the compatibility profile.
*/}}
{{- define "ryvn-gateway.ingressCompatibilityProfile" -}}
{{- $profile := default "adopt" .Values.ingressCompatibilityProfile -}}
{{- if not (has $profile (list "adopt" "create" "disabled")) -}}
{{- fail "ryvn-gateway ingressCompatibilityProfile must be one of adopt, create, or disabled" -}}
{{- end -}}
{{- $profile -}}
{{- end }}

{{/*
Resolve and validate the gateway role.
*/}}
{{- define "ryvn-gateway.gatewayRole" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $role := default "external" $gateway.role -}}
{{- if not (has $role (list "external" "internal")) -}}
{{- fail "ryvn-gateway gateway.role must be either external or internal" -}}
{{- end -}}
{{- $role -}}
{{- end }}

{{/*
Resolve the compatibility ingress class name for this gateway release.
*/}}
{{- define "ryvn-gateway.ingressClassName" -}}
{{- $compat := .Values.ingressCompatibility | default (dict) -}}
{{- $override := default "" $compat.ingressClassName -}}
{{- if ne $override "" -}}
{{- $override -}}
{{- else if eq (include "ryvn-gateway.gatewayRole" .) "internal" -}}
internal-nginx
{{- else -}}
external-nginx
{{- end -}}
{{- end }}

{{/*
Resolve the generated Service type for this gateway release.
*/}}
{{- define "ryvn-gateway.serviceType" -}}
{{- $service := .Values.service | default (dict) -}}
{{- $explicit := default "" $service.type -}}
{{- if ne $explicit "" -}}
{{- $explicit -}}
{{- else if eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "adopt" -}}
ClusterIP
{{- else -}}
LoadBalancer
{{- end -}}
{{- end }}

{{/*
Resolve the client IP attribute that i2gw should use for source-range
policies on this Gateway.
*/}}
{{- define "ryvn-gateway.clientIPAttribute" -}}
{{- $sourceIP := .Values.sourceIpPreservation | default (dict) -}}
{{- $mode := default "direct" $sourceIP.mode -}}
{{- $numTrustedProxies := int (default 0 $sourceIP.numTrustedProxies) -}}
{{- if eq $mode "disabled" -}}
none
{{- else if or (eq $mode "proxy-protocol") (gt $numTrustedProxies 0) -}}
remote.ip
{{- else -}}
source.ip
{{- end -}}
{{- end }}

{{/*
Whether this release should create an IngressClass compatibility resource.
*/}}
{{- define "ryvn-gateway.createIngressClass" -}}
{{- eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "create" -}}
{{- end }}

{{/*
Whether this release should create an IngressProxyTarget resource.
*/}}
{{- define "ryvn-gateway.createIngressProxyTarget" -}}
{{- $compat := .Values.ingressCompatibility | default (dict) -}}
{{- $proxyTarget := $compat.proxyTarget | default (dict) -}}
{{- and (eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "adopt") (ternary $proxyTarget.create true (hasKey $proxyTarget "create")) -}}
{{- end }}

{{/*
Resolve the proxy target resource name.
*/}}
{{- define "ryvn-gateway.proxyTargetName" -}}
{{- $compat := .Values.ingressCompatibility | default (dict) -}}
{{- $proxyTarget := $compat.proxyTarget | default (dict) -}}
{{- $override := default "" $proxyTarget.name -}}
{{- if ne $override "" -}}
{{- $override -}}
{{- else -}}
{{- include "ryvn-gateway.ingressClassName" . -}}
{{- end -}}
{{- end }}

{{/*
Normalize the chart-owned default HTTPS listener settings. certificateRef is
the effective Gateway API certificateRefs entry after resolving precedence:
provided certificateRef > cert-manager wildcard secret > self-signed fallback
secret. Its namespace is only set for a provided cross-namespace Secret.
*/}}
{{- define "ryvn-gateway.defaultListenerConfig" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $dl := $gateway.defaultListener | default (dict) -}}
{{- $enabled := ternary $dl.enabled true (hasKey $dl "enabled") -}}
{{- $dnsZone := default "" $dl.dnsZone -}}
{{- $hasDnsZone := ne $dnsZone "" -}}
{{- $certManager := $dl.certManager | default (dict) -}}
{{- $issuerRef := $certManager.issuerRef | default (dict) -}}
{{- $providedRef := $dl.certificateRef | default (dict) -}}
{{- $providedRefName := default "" $providedRef.name | toString | trim -}}
{{- $providedRefNamespace := default "" $providedRef.namespace | toString | trim -}}
{{- if and (ne $providedRefNamespace "") (eq $providedRefName "") -}}
{{- fail "ryvn-gateway gateway.defaultListener.certificateRef.namespace requires certificateRef.name" -}}
{{- end -}}
{{- if eq $providedRefNamespace .Release.Namespace -}}
{{- $providedRefNamespace = "" -}}
{{- end -}}
{{- $usesProvidedCertificateRef := ne $providedRefName "" -}}
{{- $hasIssuerRef := ne (default "" $issuerRef.name) "" -}}
{{- $managedSecretName := default "" $certManager.secretName -}}
{{- $fallbackSecretName := printf "%s-default-tls" (include "ryvn-gateway.fullname" .) -}}
{{- $wildcardSecretName := "" -}}
{{- if ne $managedSecretName "" -}}
{{- $wildcardSecretName = $managedSecretName -}}
{{- else if $hasDnsZone -}}
{{- $wildcardSecretName = printf "%s-gw-wildcard-tls" $dnsZone -}}
{{- end -}}
{{- $certificateRefName := $fallbackSecretName -}}
{{- if $usesProvidedCertificateRef -}}
{{- $certificateRefName = $providedRefName -}}
{{- else if $hasDnsZone -}}
{{- $certificateRefName = $wildcardSecretName -}}
{{- end -}}
enabled: {{ $enabled }}
hasDnsZone: {{ $hasDnsZone }}
dnsZone: {{ $dnsZone | quote }}
hostname: {{ ternary (printf "*.%s" $dnsZone) "" $hasDnsZone | quote }}
usesProvidedCertificateRef: {{ $usesProvidedCertificateRef }}
certificateRef:
  name: {{ $certificateRefName | quote }}
  namespace: {{ $providedRefNamespace | quote }}
usesCertManager: {{ $hasIssuerRef }}
managedSecretName: {{ $managedSecretName | quote }}
fallbackCertName: {{ $fallbackSecretName | quote }}
fallbackSecretName: {{ $fallbackSecretName | quote }}
wildcardSecretName: {{ $wildcardSecretName | quote }}
{{- if $hasIssuerRef }}
issuerRef:
  name: {{ $issuerRef.name | quote }}
  kind: {{ default "Issuer" $issuerRef.kind | quote }}
{{- end }}
{{- end }}

{{- define "ryvn-gateway.clientCertificateValidationConfig" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $cv := $gateway.clientCertificateValidation | default (dict) -}}
{{- $mode := default "" $cv.mode -}}
{{- $caBundle := default "" $cv.caBundle -}}
enabled: {{ ne $mode "" }}
caBundle: {{ $caBundle | toJson }}
hasCaBundle: {{ ne (trim $caBundle) "" }}
caConfigMapName: {{ printf "%s-client-ca" (include "ryvn-gateway.fullname" .) | quote }}
{{- end }}

{{/*
Namespaces block restricting ListenerSet attachment to Ryvn-managed
namespaces (those the agent labels with ryvn.app/managed).
*/}}
{{- define "ryvn-gateway.managedNamespaces" -}}
from: Selector
selector:
  matchLabels:
    ryvn.app/managed: ""
{{- end }}

{{/*
Validate the chart-owned listener values and listener name collisions.
*/}}
{{- define "ryvn-gateway.validateListeners" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $customListeners := $gateway.listeners | default (list) -}}
{{- $dl := include "ryvn-gateway.defaultListenerConfig" . | fromYaml -}}
{{- if and $dl.enabled $dl.usesProvidedCertificateRef $dl.usesCertManager -}}
{{- fail "ryvn-gateway gateway.defaultListener: set either certificateRef or certManager.issuerRef, not both" -}}
{{- end -}}
{{- if and $dl.enabled $dl.usesCertManager (not $dl.hasDnsZone) -}}
{{- fail "ryvn-gateway gateway.defaultListener.certManager.issuerRef requires gateway.defaultListener.dnsZone" -}}
{{- end -}}
{{- if and $dl.enabled (not $dl.usesCertManager) (ne $dl.managedSecretName "") -}}
{{- fail "ryvn-gateway gateway.defaultListener.certManager.secretName requires certManager.issuerRef.name" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone (not (or $dl.usesProvidedCertificateRef $dl.usesCertManager)) -}}
{{- fail "ryvn-gateway gateway.defaultListener.dnsZone requires either certificateRef.name or certManager.issuerRef.name" -}}
{{- end -}}
{{- if and $dl.enabled $dl.usesProvidedCertificateRef (eq $dl.certificateRef.namespace "") (eq $dl.certificateRef.name $dl.fallbackSecretName) -}}
{{- fail (printf "ryvn-gateway gateway.defaultListener.certificateRef must not reference the chart-owned fallback secret %q" $dl.fallbackSecretName) -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone $dl.usesCertManager (eq $dl.wildcardSecretName $dl.fallbackSecretName) -}}
{{- fail (printf "ryvn-gateway gateway.defaultListener.certManager.secretName must not equal the chart-owned fallback secret name %q" $dl.fallbackSecretName) -}}
{{- end -}}
{{- $cv := include "ryvn-gateway.clientCertificateValidationConfig" . | fromYaml -}}
{{- if $cv.enabled -}}
{{- if not $cv.hasCaBundle -}}
{{- fail "ryvn-gateway gateway.clientCertificateValidation requires caBundle" -}}
{{- end -}}
{{- $caBundle := trim $cv.caBundle -}}
{{- if not (and (contains "-----BEGIN CERTIFICATE-----" $caBundle) (contains "-----END CERTIFICATE-----" $caBundle)) -}}
{{- fail "ryvn-gateway gateway.clientCertificateValidation.caBundle must include a complete PEM certificate" -}}
{{- end -}}
{{- end -}}
{{- range $index, $listener := $customListeners -}}
{{- $name := default "" $listener.name -}}
{{- if and $dl.enabled (eq $name "https") -}}
{{- fail (printf "ryvn-gateway gateway.listeners[%d].name=%q collides with the chart-owned default https listener" $index $name) -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone (eq $name "http") -}}
{{- fail (printf "ryvn-gateway gateway.listeners[%d].name=%q collides with the chart-owned default http listener" $index $name) -}}
{{- end -}}
{{- end -}}
{{- if not (or $dl.enabled $customListeners) -}}
{{- fail "ryvn-gateway requires at least one listener: keep gateway.defaultListener.enabled=true or specify gateway.listeners" -}}
{{- end -}}
{{- end }}
