{{/*
Common labels
*/}}
{{- define "ryvn-admission.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: ryvn
{{- end }}

{{/*
Ryvn identities by short name. Boundaries list their writers by key.
*/}}
{{- define "ryvn-admission.identities" -}}
ryvn-agent: system:serviceaccount:ryvn-system:ryvn-agent
ryvn-net: system:serviceaccount:ryvn-system:ryvn-net
istiod: system:serviceaccount:ryvn-system:istiod
cert-manager: system:serviceaccount:cert-manager:cert-manager
{{- end }}

{{/*
Objects the agent writes for Ryvn carry one of these markers; customer charts it applies do not.
The i2gw marker is admission compatibility only.
*/}}
{{- define "ryvn-admission.managedMarkerCEL" -}}
(has(object.metadata.labels) && (
  "ryvn.app/managed" in object.metadata.labels ||
  ("networking.ryvn.app/managed-by" in object.metadata.labels &&
    object.metadata.labels["networking.ryvn.app/managed-by"] == "ryvn-net") ||
  ("i2gw.ryvn.app/managed-by" in object.metadata.labels &&
    object.metadata.labels["i2gw.ryvn.app/managed-by"] == "ryvn-i2gw-controller")
))
{{- end }}

{{/*
Kubernetes cleanup identities need UPDATE for finalizer removal and DELETE for garbage
collection and namespace teardown.
*/}}
{{- define "ryvn-admission.cleanupCEL" -}}
(request.operation in ["UPDATE", "DELETE"] && request.userInfo.username in [
  "system:kube-controller-manager",
  "system:serviceaccount:kube-system:generic-garbage-collector",
  "system:serviceaccount:kube-system:namespace-controller"
])
{{- end }}

{{/*
Renders a boundary (name, rules, writers, message; see ryvn-admission.boundaries.* below) as a
ValidatingAdmissionPolicy and Deny binding named <name>.ryvn.app. A rule lists apiGroups and
optionally resources; ryvn-agent must also carry a managed marker on CREATE/UPDATE, and the
cleanup identities pass on UPDATE/DELETE.
*/}}
{{- define "ryvn-admission.boundary" -}}
{{- $spec := .spec -}}
{{- $identities := include "ryvn-admission.identities" . | fromYaml -}}
{{- $writers := list -}}
{{- $agentWrites := false -}}
{{- range $key := $spec.writers -}}
  {{- if eq $key "ryvn-agent" -}}
    {{- $agentWrites = true -}}
  {{- else if hasKey $identities $key -}}
    {{- $writers = append $writers (index $identities $key) -}}
  {{- else -}}
    {{- fail (printf "boundary %s: unknown writer %q" $spec.name $key) -}}
  {{- end -}}
{{- end -}}
{{- $allowed := list -}}
{{- if $writers -}}
  {{- $allowed = append $allowed (printf "request.userInfo.username in %s" (toJson $writers)) -}}
{{- end -}}
{{- if $agentWrites -}}
  {{- $allowed = append $allowed (printf "(request.userInfo.username == %s && (request.operation == \"DELETE\" || %s))" (toJson (index $identities "ryvn-agent")) (include "ryvn-admission.managedMarkerCEL" .)) -}}
{{- end -}}
{{- $allowed = append $allowed (include "ryvn-admission.cleanupCEL" .) -}}
apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicy
metadata:
  name: {{ $spec.name }}.ryvn.app
  labels:
    {{- include "ryvn-admission.labels" .root | nindent 4 }}
spec:
  failurePolicy: Fail
  {{- with $spec.matchConditions }}
  matchConditions:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with $spec.variables }}
  variables:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  matchConstraints:
    matchPolicy: Equivalent
    resourceRules:
      {{- range $rule := $spec.rules }}
      - apiGroups:
          {{- $rule.apiGroups | toYaml | nindent 10 }}
        apiVersions: ["*"]
        operations: [CREATE, UPDATE, DELETE]
        resources:
          {{- default (list "*") $rule.resources | toYaml | nindent 10 }}
      {{- end }}
  validations:
    - expression: >-
        {{- $allowed | join " ||\n" | nindent 8 }}
      message: {{ $spec.message | quote }}
      reason: Forbidden
---
apiVersion: admissionregistration.k8s.io/v1
kind: ValidatingAdmissionPolicyBinding
metadata:
  name: {{ $spec.name }}.ryvn.app
  labels:
    {{- include "ryvn-admission.labels" .root | nindent 4 }}
spec:
  policyName: {{ $spec.name }}.ryvn.app
  validationActions: [Deny]
{{- end }}

{{/*
Gateway API resources managed by Ryvn are the only resources in the networking
boundary. Customer-run Gateway API controllers are admitted untouched. Routes and
ListenerSets are scoped by parent namespace alone (never parent kind): Ryvn routes
attach to both Gateways and ListenerSets, and every Ryvn ListenerSet lives in a
managed namespace.
*/}}
{{- define "ryvn-admission.managedGatewayCEL" -}}
{{- $classes := toJson .Values.networking.managedGatewayClasses -}}
{{- $ns := toJson .Values.networking.managedGatewayNamespaces -}}
!(request.resource.group in ["gateway.networking.k8s.io","gateway.networking.x-k8s.io"]) || (
  request.resource.resource == "gatewayclasses" ? (object != null ? object : oldObject).metadata.name in {{ $classes }} :
  request.resource.resource == "gateways" ? (has((object != null ? object : oldObject).spec.gatewayClassName) && (object != null ? object : oldObject).spec.gatewayClassName in {{ $classes }}) :
  request.resource.resource in ["httproutes","grpcroutes","tcproutes","tlsroutes","udproutes"] ? (
    has((object != null ? object : oldObject).spec.parentRefs) && (object != null ? object : oldObject).spec.parentRefs.exists(p,
      (has(p.namespace) ? p.namespace : (object != null ? object : oldObject).metadata.namespace) in {{ $ns -}})) :
  request.resource.resource in ["listenersets","xlistenersets"] ? (
    has((object != null ? object : oldObject).spec.parentRef) &&
    ((has((object != null ? object : oldObject).spec.parentRef.namespace) ? (object != null ? object : oldObject).spec.parentRef.namespace : (object != null ? object : oldObject).metadata.namespace) in {{ $ns -}})) :
  (has((object != null ? object : oldObject).metadata.namespace) && (object != null ? object : oldObject).metadata.namespace in {{ $ns -}})
)
{{- end }}

{{/*
Resources in these groups are Ryvn's to write. Kinds under networking.ryvn.app are user-authored,
so RBAC governs them and only their CRDs are protected (crds.yaml).
*/}}
{{- define "ryvn-admission.boundaries.networking" -}}
name: networking
rules:
  - apiGroups:
      - gateway.networking.k8s.io
      - authentication.istio.io
      - config.istio.io
      - extensions.istio.io
      - install.istio.io
      - i2gw.ryvn.app
      - networking.istio.io
      - security.istio.io
      - telemetry.istio.io
  # Experimental XListenerSets may not attach to Ryvn Gateways. Customer controllers
  # ship this CRD themselves, so it is not held by crds.ryvn.app.
  - apiGroups:
      - gateway.networking.x-k8s.io
    protectCRDs: false
writers: [ryvn-agent, ryvn-net, istiod, cert-manager]
matchConditions:
  - name: ryvn-managed-gateway-resources-only
    expression: |-
      {{- include "ryvn-admission.managedGatewayCEL" . | nindent 6 }}
message: Direct use of Gateway API and Istio resources is not yet supported on Ryvn-managed clusters. Use a networking.ryvn.app Route instead.
{{- end }}
