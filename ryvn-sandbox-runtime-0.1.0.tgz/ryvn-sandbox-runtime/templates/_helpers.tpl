{{/*
Common labels
*/}}
{{- define "ryvn-sandbox-runtime.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Node bootstrap. The shell script part runs in cloud-init's user-scripts stage,
which AL2023 orders before nodeadm-run.service. It installs gvisor-install.service
and makes nodeadm-run.service require it, so the kubelet only ever starts on a
node that has a working sandbox runtime: a failed install leaves the node out of
the cluster and Karpenter replaces it.
*/}}
{{- define "ryvn-sandbox-runtime.userData" -}}
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="//"

--//
Content-Type: application/node.eks.aws

apiVersion: node.eks.aws/v1alpha1
kind: NodeConfig
spec:
  containerd:
    config: |
{{ .Values.nodeClass.containerdConfig | trim | indent 6 }}

--//
Content-Type: text/x-shellscript; charset="us-ascii"

#!/usr/bin/env bash
set -euo pipefail

cat > /usr/local/sbin/ryvn-sandbox-runtime-install.sh <<'GVISOR_INSTALL'
#!/usr/bin/env bash
set -euo pipefail

ARCH="$(uname -m)"
case "${ARCH}" in
{{- range $arch, $checksum := .Values.gvisor.checksums }}
  {{ $arch }}) CHECKSUM="{{ $checksum }}" ;;
{{- end }}
  *) echo "gvisor: no pinned checksum for ${ARCH}" >&2; exit 1 ;;
esac

command -v bzip2 >/dev/null || dnf install -y bzip2

WORK_DIR="$(mktemp -d)"
trap 'rm -rf "${WORK_DIR}"' EXIT

curl -fsSL --retry 5 --retry-delay 3 \
  -o "${WORK_DIR}/gvisor.tar.bz2" \
  "{{ .Values.gvisor.releaseUrl }}/{{ .Values.gvisor.version }}/${ARCH}/gvisor.tar.bz2"
echo "${CHECKSUM}  ${WORK_DIR}/gvisor.tar.bz2" | sha512sum -c -

# The tarball holds runsc, containerd-shim-runsc-v1 and a gvisor-bin/ directory
# of helpers runsc resolves relative to its own path, so it extracts as a whole
# into the install dir.
tar -xjf "${WORK_DIR}/gvisor.tar.bz2" -C "{{ .Values.gvisor.installDir }}"
ln -sf "{{ .Values.gvisor.installDir }}/runsc" /usr/bin/runsc
ln -sf "{{ .Values.gvisor.installDir }}/containerd-shim-runsc-v1" /usr/bin/containerd-shim-runsc-v1
runsc --version

# Shim config referenced by ConfigPath in the containerd runtime options
# (https://gvisor.dev/docs/user_guide/containerd/configuration/).
install -d /etc/containerd
cat > /etc/containerd/runsc.toml <<'RUNSC_CONFIG'
[runsc_config]
{{- range $flag, $value := .Values.gvisor.runscConfig }}
  {{ $flag }} = {{ $value | quote }}
{{- end }}
RUNSC_CONFIG
GVISOR_INSTALL
chmod 0755 /usr/local/sbin/ryvn-sandbox-runtime-install.sh

cat > /etc/systemd/system/gvisor-install.service <<'GVISOR_UNIT'
[Unit]
Description=Install gVisor (runsc) for the sandbox runtime
Before=nodeadm-run.service
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/usr/local/sbin/ryvn-sandbox-runtime-install.sh
GVISOR_UNIT

# nodeadm-run.service starts the kubelet, and it only orders itself after
# cloud-final.service without requiring it to have succeeded. Requiring the
# install unit is what makes the node fail to join rather than join without a
# sandbox runtime.
mkdir -p /etc/systemd/system/nodeadm-run.service.d
cat > /etc/systemd/system/nodeadm-run.service.d/10-gvisor.conf <<'GVISOR_DROPIN'
[Unit]
Requires=gvisor-install.service
After=gvisor-install.service
GVISOR_DROPIN

systemctl daemon-reload
systemctl start gvisor-install.service
{{- with .Values.nodeClass.extraUserData }}

{{ . | trim }}
{{- end }}

--//--
{{- end }}
