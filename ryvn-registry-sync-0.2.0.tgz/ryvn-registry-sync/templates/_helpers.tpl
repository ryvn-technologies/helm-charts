{{- define "registry-sync.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "registry-sync.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "registry-sync.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "registry-sync.labels" -}}
helm.sh/chart: {{ include "registry-sync.chart" . }}
{{ include "registry-sync.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: registry-sync-worker
{{- end }}

{{- define "registry-sync.selectorLabels" -}}
app.kubernetes.io/name: {{ include "registry-sync.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "registry-sync.serviceAccountName" -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "registry-sync.fullname" . -}}
{{- end -}}
{{- end }}

{{- define "registry-sync.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{ printf "%s:%s" .Values.image.repository $tag }}
{{- end }}

{{/*
Mount paths shared by the ConfigMap-rendered worker.yaml and the Deployment.
*/}}
{{- define "registry-sync.configDir" -}}/etc/ryvn/registry-sync{{- end }}
{{- define "registry-sync.hubDir" -}}/var/run/ryvn/hub{{- end }}
{{- define "registry-sync.sourceDir" -}}/var/run/ryvn/source{{- end }}
{{- define "registry-sync.destinationDir" -}}/var/run/ryvn/destination{{- end }}

{{/*
Renders the worker's LocalCredentials block for one side. Takes a dict with
"side" (source|destination), "values" (the credentials values) and "dir"
(the Docker config mount directory).
*/}}
{{- define "registry-sync.credentials" -}}
{{- $selected := 0 -}}
{{- if .values.dockerConfigSecret.name }}{{ $selected = add $selected 1 }}{{ end -}}
{{- if .values.cloudIdentity }}{{ $selected = add $selected 1 }}{{ end -}}
{{- if .values.hubRegistry }}{{ $selected = add $selected 1 }}{{ end -}}
{{- if gt (int $selected) 1 -}}
{{- fail (printf "%sCredentials must select at most one of dockerConfigSecret.name, cloudIdentity or hubRegistry" .side) -}}
{{- end -}}
{{- if and (eq (int $selected) 0) (not .values.anonymous) -}}
{{- fail (printf "%sCredentials must select dockerConfigSecret.name, cloudIdentity or hubRegistry, or set anonymous: true" .side) -}}
{{- end -}}
{{- if .values.dockerConfigSecret.name -}}
dockerConfigFile: {{ printf "%s/%s" .dir .values.dockerConfigSecret.key | quote }}
{{- else if .values.cloudIdentity -}}
{{- if not (has .values.cloudIdentity (list "aws" "gcp" "azure")) -}}
{{- fail (printf "%sCredentials.cloudIdentity must be one of aws, gcp or azure" .side) -}}
{{- end -}}
cloudIdentity: {{ .values.cloudIdentity | quote }}
{{- else if .values.hubRegistry -}}
hubRegistry: {{ .values.hubRegistry | quote }}
{{- else -}}
anonymous: true
{{- end -}}
{{- end }}
