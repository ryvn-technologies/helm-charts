# ryvn-collector

Wraps Grafana Alloy to ship logs, Kubernetes events and Prometheus metrics from a
customer environment to its assigned observability connections, tenanted by organization.

Read the [upgrade and release prerequisites](#releases) before upgrading this chart.

## Scraping a workload's own exporter

Alloy discovers Services annotated for scraping. Annotations live on the
Service; labels used for attribution live on its Endpoints.

| Annotation | Effect |
| --- | --- |
| `ryvn.app/scrape-metrics: "true"` | Required. Opts the Service's ready endpoints into scraping. |
| `ryvn.app/metrics-port` | Port number to scrape. Used verbatim in the target address, so a port *name* does not work. |
| `ryvn.app/metrics-path` | Metrics path; defaults to `/metrics`. |
| `ryvn.app/scrape-interval` | Per-target interval, overriding the chart default. Also lowers the timeout, since a timeout may not exceed its interval. |
| `ryvn.app/scrape-timeout` | Per-target timeout; wins over the value derived from the interval. |
| `ryvn.app/drop-runtime-metrics: "true"` | Drops the exporter's own `go_*`, `process_*` and `promhttp_*` series (`features.metrics.dropMetricNameRegex`). |

| Label | Effect |
| --- | --- |
| `app.kubernetes.io/instance` | Default value of the `installation` label. |
| `ryvn.app/installation-name` | Overrides `installation`, so an exporter deployed beside a resource attributes its series to that resource's installation rather than to the exporter's own release. |
| `app.kubernetes.io/name` | Value of the `service` label. |

Every metric also carries `environment`; the organization is the Mimir tenant
(`X-Scope-OrgID`), not a label. Scoping a query by namespace alone is not
enough: installations in an environment share a namespace, so use `environment`
plus `installation`.

`features.metrics.keepSettingsMetricNames` and `dropSettingsMetricNameRegex`
trim high-cardinality, never-changing series (postgres-exporter reports one
series per server setting); the named metrics survive the drop.

## Explicit default and assigned destinations

The backend/platform renderer supplies these values; there is no chart-selected
hub endpoint or automatic failover:

| Value | Meaning |
| --- | --- |
| `defaultConnectionId` | Selected assignment UUID. Empty means initialization is pending. |
| `destinations` | All authorized assignments, including unavailable ones. |
| `requiredConnectionIds` | Trusted platform-derived required publication UUIDs, not a second default. |

```yaml
defaultConnectionId: 11111111-1111-1111-1111-111111111111
requiredConnectionIds: []
destinations:
  - name: acme-observability
    connectionId: 11111111-1111-1111-1111-111111111111
    logsUrl: https://loki.acme.example
    metricsUrl: https://mimir.acme.example
    available: true
    unavailableReason: ""
  - name: pending-stack
    connectionId: 22222222-2222-2222-2222-222222222222
    available: false
    unavailableReason: "authorization pending"
```

URLs are ingest bases: the chart appends `/loki/api/v1/push`, `/otlp` or
`/api/v1/push`, trimming a trailing slash. Available entries require both
HTTP(S) endpoints. Readiness is explicit, not inferred from URL presence.
UUIDs are canonical lowercase and aliases are case-sensitive Kubernetes label
values; `default` is reserved. Unavailable assignments retain their selector
identity but render no writer, even if an old endpoint is present.

### Workload selection

A Pod label selects its container-log destination. A Service label selects its
annotated, ready endpoints' metric destination. The label key is
`destinationLabel` (default `ryvn.app/telemetry-destination`).

| Selector | Route |
| --- | --- |
| Missing, empty or exactly `default` | Selected default |
| Known assigned alias | That connection |
| Unknown alias, including case mismatch | Selected default, with an unresolved-selection diagnostic |
| Known unavailable alias | Retain identity; no writer or fallback |

Changing the default does not change aliases. Removing an assignment makes its
former alias unknown, so future data follows the fallback rule. A pending or
unavailable default never redirects to another assignment or public endpoint.

In environments with restricted egress, allow the destination hostnames before
switching telemetry destinations. Collector updates do not wait for firewall
changes, and delivery may fail until the firewall rules are applied.

Node/cAdvisor, ordinary kube-state-metrics (KSM), collector self metrics,
ServiceMonitors and the existing Kubernetes-events OTLP pipeline use the selected
default. Collection switches, exclusions, annotation and readiness filters still
apply; selecting a destination does not opt a Service into scraping. This adds
neither traces nor a new OTLP receiver.

Selector resolution occurs before disjoint UUID collection routes. Default and
explicit alias use the same Pod tail, Service scrape and writer. Component
identities derive from the UUID (`dest_` prefix, hyphens replaced by underscores)
and survive default/alias edits. Distinct UUIDs sharing an endpoint remain
independent because endpoint equality does not establish equivalent authorization.

### Capacity publication and protection

The platform KSM source is scraped once with Alloy clustering enabled. Its output
splits into disjoint subsets:

- CPU/memory `kube_node_status_capacity` and `kube_node_labels` go once to each
  available authorized assigned UUID, including assignments with no workload matches.
- Remaining filtered KSM metrics go to the selected default when optional metrics
  collection is enabled. Capacity/node-label samples are excluded from this branch.

Organization tenancy and environment, node, resource and node-group attribution
are preserved. No full KSM inventory is replicated.

A nonempty `requiredConnectionIds` keeps the KSM discovery/scrape and capacity
branch enabled even when optional metrics/logs are disabled or no ordinary
default exists. Missing required assignments fail rendering; unavailable required
assignments remain explicit faults. Protection is supplied only by trusted
platform configuration on `ryvn-prod`; the chart does not infer it from names or
inject a Ryvn-central destination on BYOC hubs. Backend enforcement protects the
assignment and platform KSM dependency against overrides; chart values are not
the security boundary.

### Diagnostics and delivery

ConfigMap annotations expose `ryvn.app/telemetry-default-status` (`pending`,
`available`, `unavailable`), `ryvn.app/telemetry-unavailable-destinations` and
`ryvn.app/telemetry-required-unavailable`. These describe configuration readiness,
not verified network delivery.

The local Alloy UI exposes eligible unresolved Pod and Service targets through
`discovery.relabel.pod_logs_unresolved` and
`discovery.relabel.prometheus_metrics_unresolved`, including when the default
cannot ingest. These diagnostic views do not tail or scrape a second time.
Unknown Pod lines reaching the default tail increment
`ryvn_collector_unresolved_destination_lines_total`, with a 24h idle lifetime
and no arbitrary selector-value label. The counter means unresolved selection,
not dropped logs. Self metrics publish to the default when it is available;
local diagnostics do not require that backend to receive metrics.

Each UUID has independent Loki retries (10 retries, 5m maximum backoff) and a
Mimir queue (`retry_on_http_429`, 5s batch deadline). Existing Alloy buffering,
resource limits and event-exporter delivery behavior remain unchanged.
There is no new WAL persistence, replay system or outage SLA.

### Authentication and unchanged query behavior

Every writer reuses the collector OAuth2 client credentials and organization /
environment tenant headers; no credentials live in assignments.
`auth.tokenUrl` and `auth.projectId` remain configurable, with
`RYVN_TOKEN_URL` and `RYVN_PROJECT_ID` overrides.
Legacy `endpoints.loki` / `endpoints.mimir`, `RYVN_LOKI_URL` and
`RYVN_MIMIR_URL` are not routing authorities and are ignored.

Changing the default affects future collection only. Existing data stays in its
backend. Native queries, cloud probes and query destination selection do not
follow this setting; customer backends retain their existing query access paths.
No query federation or history migration is added.

### Native-cloud receiver regression

The cloud module owns resource admission. The chart adds the environment label
and forwards admitted samples to the selected UUID writer without filtering by
normalized metric names.

`TestDedicatedCloudNativeReceiver` renders the dedicated blueprint's collector
child and chart with synthetic authorized assignments, then runs the module's
actual admission relabeler, chart tail and UUID writers in Alloy against a local
remote-write receiver. Only exporter/discovery I/O is replaced with fixture
samples. It checks native names/values, attribution, tenancy/authentication,
default A/B, pending/unavailable defaults, and unadmitted/self-metric negatives.
It does not validate cloud API discovery, backend authorization or upgrade safety.

Run it with the pinned chart Alloy binary and **native renderer** artifacts from
the stack being composed (this branch's older normalized golden is not equivalent):

```sh
ALLOY_BINARY=/path/to/alloy \
CLOUD_METRICS_MODULE=/path/to/native/testdata/cloud_metrics_module.alloy \
CLOUD_METRICS_BLUEPRINT=/path/to/native/cloud-metrics.blueprint.yaml \
go test -count=1 -run TestDedicatedCloudNativeReceiver -v ./charts/ryvn-collector/tests
```

For GCP or Azure, set `CLOUD_METRICS_PROVIDER=gcp` or
`CLOUD_METRICS_PROVIDER=azure` and use the native renderer's corresponding
`cloud_metrics_module_gcp.alloy` or `cloud_metrics_module_azure.alloy` and matching
blueprint. The Azure fixture checks both legacy Redis and Managed Redis
(`Microsoft.Cache/redisEnterprise`), Maximum and Total series, unchanged
`cacheRead`/`cacheWrite` per-second values, distinct `InstanceId` shard values
(the pinned exporter's single-dimension `dimension` label), and exact
ARM identity (including undeclared/child-resource/wrong-family negatives).
The AWS fixture requires account-scoped native claims and also rejects samples
with a missing or different account ID.

The rendered dedicated workload must remain a singleton Deployment with its own
ServiceAccount and mounted main ConfigMap, a release-scoped module ConfigMap read
by `remote.kubernetes.configmap`, and no platform pipelines. Azure workload-identity
outputs are synthetic transport fixtures, not backend authorization or actual
managed-dispatch evidence. This receiver seam does not establish chart/module/
renderer composition or release identity; PR-8 must validate that actual path.

The test fails if module admission drops expected samples; it does not bypass
admission to make a collector
test pass. Without the binary/module inputs this opt-in integration test skips;
the chart's Helm regressions still run normally.

## Releases

This chart is **not independently upgrade-safe or releasable**. Existing platform
values lack `defaultConnectionId` and destination `available` fields. Upgrading
with those values renders no ingest writers. Retained legacy endpoint values do
not restore those routes. Chart unit tests validate the new input contract; they
do not prove existing installations can upgrade safely.

The [approved plan at b779a45449](https://github.com/ryvn-technologies/ryvn/blob/b779a4544946a12b13ce6bb60759a3034f1ba69d/docs-internal/changes/observability-default-destination/plan.md#sequencing)
allows chart source to merge as an unreleased slice after review. It holds
**all collector publication/promotion from main, including intervening releases**,
until these prerequisites are met:

- **PR-5 (ENG-2520)** must supply authorized defaults, assignment readiness and
  trusted required destination IDs, with matching authorization and network
  configuration.
- **PR-8 (ENG-2523)** must feed actual values from the base/AWS/Azure/GCP platform
  and standalone production rendering paths into upgrade and receiver tests.
  Verify active Loki/Mimir writers, delivery and protected capacity publication,
  not just hand-authored chart fixtures. Document the matching backend,
  initialized data and platform/standalone configuration being applied before
  the chart upgrade; operator confirmation of those prerequisites is required.

The standalone `ryvn-iac/environments/ryvn-prod/ryvn-collector.installation.yaml`
tracks `production` and does not use the platform blueprint's collector child.
**PR-5 explicitly owns its configuration update**, including the authorized
default, destination readiness and required billing destination. Production
sync/application remains a human prerequisite, not work performed by this chart
packet. Platform template changes alone do not fix this consumer.

The release workflow (`.github/workflows/ryvn-collector-release.yaml`) runs on a
merged collector PR with `auto-release:ryvn-collector`. It does not enforce the
prerequisites above. Withholding the label from this packet prevents its release,
but a later labeled collector PR can still publish the changed chart. The release
hold applies to that later publication too, not just this PR's labels. Do not add
the label, bump the chart version, publish or promote it before the prerequisites
are met. CI generates the published version and rewrites `Chart.yaml`.

The reusable workflow (`.github/workflows/ryvn-auto-release.yml`) creates a Ryvn
release directly on the generated channel; a separate manual promotion is not a
guaranteed safety barrier. Platform collector children track `stable` on AWS,
Azure and GCP; the standalone production collector tracks `production`.
`config/hub-catalog-sync.yaml` distributes the newest stable collector release
to Orbit, while `config/hub-catalog-sync-ambitious.yaml` distributes production
and stable to Ambitious. PR-8 must cover both channel paths, not just stable.
