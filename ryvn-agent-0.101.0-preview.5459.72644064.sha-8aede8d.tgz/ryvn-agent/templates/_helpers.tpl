{{/*
Expand the name of the k8s-agent.
*/}}
{{- define "chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains k8s-agent name it will be used as a full name.
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create k8s-agent name and version as used by the k8s-agent label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "chart.labels" -}}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name - uses existing name if provided, otherwise falls back to chart fullname
*/}}
{{- define "chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "chart.fullname" . -}}
{{- end -}}
{{- end }}

{{/*
Target environment - uses targetEnv if set, otherwise falls back to ryvn.env.name
*/}}
{{- define "targetEnvironment" -}}
{{- if .Values.targetEnv -}}
{{- .Values.targetEnv -}}
{{- else if .Values.ryvn -}}
{{- .Values.ryvn.env.name -}}
{{- end -}}
{{- end }}

{{/*
CEL list of ingress classes managed by i2gw.
Explicit ingressClassMapping wins. If it is omitted, derive classes from the
same built-in ingressCompatibilityProfile defaults used by the agent.
*/}}
{{- define "i2gw.managedIngressClassCELList" -}}
{{- $classes := list -}}
{{- $mapping := trim .Values.i2gw.ingressClassMapping -}}
{{- if $mapping -}}
{{- range $entry := splitList "," $mapping -}}
{{- $entry = trim $entry -}}
{{- if $entry -}}
{{- $parts := splitList "=" $entry -}}
{{- $class := trim (index $parts 0) -}}
{{- if $class -}}
{{- $classes = append $classes (printf "%q" $class) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- else -}}
{{- $profile := trim .Values.i2gw.ingressCompatibilityProfile -}}
{{- if eq $profile "adopt" -}}
{{- $classes = append $classes (printf "%q" "external-nginx") -}}
{{- $classes = append $classes (printf "%q" "internal-nginx") -}}
{{- else if eq $profile "create" -}}
{{- $classes = append $classes (printf "%q" "external-ryvn") -}}
{{- $classes = append $classes (printf "%q" "internal-ryvn") -}}
{{- end -}}
{{- end -}}
[{{ join ", " $classes }}]
{{- end }}
