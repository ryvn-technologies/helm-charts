# ryvn-istio-base

Wraps Istio's base chart, which installs the Istio CRDs and points the default
validating webhook at istiod in `ryvn-system`. Upstream overrides go under `base`.
Keep the Helm release name `istio-base` and namespace `ryvn-system`.

## Bumping Istio

Set `version`, `appVersion` and the `base` dependency version in `Chart.yaml` to the
new Istio version and run `helm dependency update charts/ryvn-istio-base`. Bump
`charts/ryvn-istiod` in the same PR. Merge with the `auto-release:istio-base` label.
Chart versions follow Istio's, so a values-only change ships with the next Istio
version.
