{{/*
Canonical environment UUID. The values schema already enforces the lowercase
hyphenated 36 byte spelling; this re-checks it so a render without schema
validation still fails closed instead of deriving a name from a display key.
*/}}
{{- define "access-operator.environmentId" -}}
{{- $id := required "environmentId is required" .Values.environmentId -}}
{{- if not (regexMatch "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$" $id) -}}
{{- fail (printf "environmentId %q must be a canonical lowercase UUID" $id) -}}
{{- end -}}
{{- if eq $id "00000000-0000-0000-0000-000000000000" -}}
{{- fail "environmentId must not be the nil UUID" -}}
{{- end -}}
{{- $id -}}
{{- end }}

{{/*
Workload and ServiceAccount name: access-operator-<environmentId>. Fixed by
docs-internal/access-naming.md and intentionally not overridable — the manager
creates the ServiceAccount under exactly this name and the guard registers it
as the environment's projector identity. Release, namespace and chart names
never enter it.
*/}}
{{- define "access-operator.name" -}}
{{- printf "access-operator-%s" (include "access-operator.environmentId" .) -}}
{{- end }}

{{/*
Intent mailbox name: access-intent-<environmentId>. Read-only for the
operator; the chart never creates it.
*/}}
{{- define "access-operator.intentConfigMapName" -}}
{{- printf "access-intent-%s" (include "access-operator.environmentId" .) -}}
{{- end }}

{{/*
Chart name and version as used by the chart label.
*/}}
{{- define "access-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Selector labels. The 36 byte environment UUID is part of the selector so two
releases in one namespace never select each other's Pods.
*/}}
{{- define "access-operator.selectorLabels" -}}
app.kubernetes.io/name: access-operator
app.kubernetes.io/instance: {{ .Release.Name }}
access.ryvn.app/environment-id: {{ include "access-operator.environmentId" . | quote }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "access-operator.labels" -}}
helm.sh/chart: {{ include "access-operator.chart" . }}
{{ include "access-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
