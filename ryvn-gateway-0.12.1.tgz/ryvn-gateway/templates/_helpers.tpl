{{/*
Expand the name of the chart.
*/}}
{{- define "ryvn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ryvn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ryvn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create the metrics Service name.
*/}}
{{- define "ryvn-gateway.metricsServiceName" -}}
{{- printf "%s-gw-metrics" (include "ryvn-gateway.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create the API readiness hook resource name.
*/}}
{{- define "ryvn-gateway.apiReadinessHookName" -}}
{{- printf "%s-api-readiness" (include "ryvn-gateway.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the ServiceAccount name used by the API readiness hook.
*/}}
{{- define "ryvn-gateway.apiReadinessServiceAccountName" -}}
{{- $apiReadiness := .Values.apiReadiness | default (dict) -}}
{{- $serviceAccount := $apiReadiness.serviceAccount | default (dict) -}}
{{- if (ternary $serviceAccount.create true (hasKey $serviceAccount "create")) -}}
{{- default (include "ryvn-gateway.apiReadinessHookName" .) $serviceAccount.name -}}
{{- else -}}
{{- default "default" $serviceAccount.name -}}
{{- end -}}
{{- end }}

{{/*
Create the cluster-scoped RBAC resource name used by the API readiness hook.
*/}}
{{- define "ryvn-gateway.apiReadinessClusterRoleName" -}}
{{- printf "%s-%s" (include "ryvn-gateway.apiReadinessHookName" .) (.Release.Namespace | sha256sum | trunc 8) | trunc 63 | trimSuffix "-" -}}
{{- end }}

{{/*
Create the metrics Telemetry resource name.
*/}}
{{- define "ryvn-gateway.metricsTelemetryName" -}}
{{- printf "%s-gw-metrics-telemetry" (include "ryvn-gateway.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ryvn-gateway.labels" -}}
helm.sh/chart: {{ include "ryvn-gateway.chart" . }}
{{ include "ryvn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ryvn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Istio labels generated Gateway data-plane pods with the Gateway name.
*/}}
{{- define "ryvn-gateway.gatewayPodSelectorLabels" -}}
gateway.networking.k8s.io/gateway-name: {{ include "ryvn-gateway.fullname" . }}
{{- end }}

{{/*
Resolve and validate the compatibility profile.
*/}}
{{- define "ryvn-gateway.ingressCompatibilityProfile" -}}
{{- $profile := default "adopt" .Values.ingressCompatibilityProfile -}}
{{- if not (has $profile (list "adopt" "create" "disabled")) -}}
{{- fail "ryvn-gateway ingressCompatibilityProfile must be one of adopt, create, or disabled" -}}
{{- end -}}
{{- $profile -}}
{{- end }}

{{/*
Resolve and validate the gateway role.
*/}}
{{- define "ryvn-gateway.gatewayRole" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $role := default "external" $gateway.role -}}
{{- if not (has $role (list "external" "internal")) -}}
{{- fail "ryvn-gateway gateway.role must be either external or internal" -}}
{{- end -}}
{{- $role -}}
{{- end }}

{{/*
Resolve the compatibility ingress class name for this gateway release.
*/}}
{{- define "ryvn-gateway.ingressClassName" -}}
{{- $compat := .Values.ingressCompatibility | default (dict) -}}
{{- $override := default "" $compat.ingressClassName -}}
{{- if ne $override "" -}}
{{- $override -}}
{{- else if eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "create" -}}
{{- if eq (include "ryvn-gateway.gatewayRole" .) "internal" -}}
internal-ryvn
{{- else -}}
external-ryvn
{{- end -}}
{{- else if eq (include "ryvn-gateway.gatewayRole" .) "internal" -}}
internal-nginx
{{- else -}}
external-nginx
{{- end -}}
{{- end }}

{{/*
Resolve the generated Service type for this gateway release.
*/}}
{{- define "ryvn-gateway.serviceType" -}}
{{- $service := .Values.service | default (dict) -}}
{{- $explicit := default "" $service.type -}}
{{- if ne $explicit "" -}}
{{- $explicit -}}
{{- else if eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "adopt" -}}
ClusterIP
{{- else -}}
LoadBalancer
{{- end -}}
{{- end }}

{{/*
Resolve the client IP attribute that i2gw should use for source-range
policies on this Gateway.
*/}}
{{- define "ryvn-gateway.clientIPAttribute" -}}
{{- $sourceIP := .Values.sourceIpPreservation | default (dict) -}}
{{- $mode := default "direct" $sourceIP.mode -}}
{{- $numTrustedProxies := int (default 0 $sourceIP.numTrustedProxies) -}}
{{- if eq $mode "disabled" -}}
none
{{- else if or (eq $mode "proxy-protocol") (gt $numTrustedProxies 0) -}}
remote.ip
{{- else -}}
source.ip
{{- end -}}
{{- end }}

{{/*
Whether this release should create an IngressClass compatibility resource.
*/}}
{{- define "ryvn-gateway.createIngressClass" -}}
{{- eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "create" -}}
{{- end }}

{{/*
Whether this release should create an IngressProxyTarget resource.
*/}}
{{- define "ryvn-gateway.createIngressProxyTarget" -}}
{{- $compat := .Values.ingressCompatibility | default (dict) -}}
{{- $proxyTarget := $compat.proxyTarget | default (dict) -}}
{{- and (eq (include "ryvn-gateway.ingressCompatibilityProfile" .) "adopt") (ternary $proxyTarget.create true (hasKey $proxyTarget "create")) -}}
{{- end }}

{{/*
Resolve the proxy target resource name.
*/}}
{{- define "ryvn-gateway.proxyTargetName" -}}
{{- $compat := .Values.ingressCompatibility | default (dict) -}}
{{- $proxyTarget := $compat.proxyTarget | default (dict) -}}
{{- $override := default "" $proxyTarget.name -}}
{{- if ne $override "" -}}
{{- $override -}}
{{- else -}}
{{- include "ryvn-gateway.ingressClassName" . -}}
{{- end -}}
{{- end }}

{{/*
Normalize the chart-owned default HTTPS listener settings.
*/}}
{{- define "ryvn-gateway.defaultListenerConfig" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $dl := $gateway.defaultListener | default (dict) -}}
{{- $enabled := ternary $dl.enabled true (hasKey $dl "enabled") -}}
{{- $dnsZone := default "" $dl.dnsZone -}}
{{- $hasDnsZone := ne $dnsZone "" -}}
{{- $certManager := $dl.certManager | default (dict) -}}
{{- $issuerRef := $certManager.issuerRef | default (dict) -}}
{{- $hasExistingSecret := ne (default "" $dl.existingSecretName) "" -}}
{{- $hasIssuerRef := ne (default "" $issuerRef.name) "" -}}
{{- $managedSecretName := default "" $certManager.secretName -}}
{{- $secretName := printf "%s-default-tls" (include "ryvn-gateway.fullname" .) -}}
{{- if $hasExistingSecret -}}
{{- $secretName = $dl.existingSecretName -}}
{{- else if ne $managedSecretName "" -}}
{{- $secretName = $managedSecretName -}}
{{- else if $hasDnsZone -}}
{{- $secretName = printf "%s-gw-wildcard-tls" $dnsZone -}}
{{- end -}}
{{- $certName := printf "%s-default-tls" (include "ryvn-gateway.fullname" .) -}}
{{- if $hasDnsZone -}}
{{- $certName = printf "%s-gw-wildcard" $dnsZone -}}
{{- end -}}
enabled: {{ $enabled }}
certName: {{ $certName | quote }}
hasDnsZone: {{ $hasDnsZone }}
dnsZone: {{ $dnsZone | quote }}
hostname: {{ ternary (printf "*.%s" $dnsZone) "" $hasDnsZone | quote }}
usesExistingSecret: {{ $hasExistingSecret }}
usesCertManager: {{ $hasIssuerRef }}
managedSecretName: {{ $managedSecretName | quote }}
secretName: {{ $secretName | quote }}
{{- if $hasDnsZone }}
dnsNames:
  - {{ printf "*.%s" $dnsZone | quote }}
  - {{ $dnsZone | quote }}
{{- end }}
{{- if $hasIssuerRef }}
issuerRef:
  name: {{ $issuerRef.name | quote }}
  kind: {{ default "Issuer" $issuerRef.kind | quote }}
{{- end }}
{{- end }}

{{/*
Normalize the chart-owned default HTTP listener settings.
*/}}
{{- define "ryvn-gateway.defaultHTTPListenerConfig" -}}
{{- $defaultListener := include "ryvn-gateway.defaultListenerConfig" . | fromYaml -}}
{{- $hostname := default "" $defaultListener.hostname -}}
enabled: {{ and $defaultListener.enabled (ne $hostname "") }}
hostname: {{ $hostname | quote }}
hasHostname: {{ ne $hostname "" }}
{{- end }}

{{/*
Validate the chart-owned listener values and listener name collisions.
*/}}
{{- define "ryvn-gateway.validateListeners" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $customListeners := $gateway.listeners | default (list) -}}
{{- $dl := include "ryvn-gateway.defaultListenerConfig" . | fromYaml -}}
{{- $http := include "ryvn-gateway.defaultHTTPListenerConfig" . | fromYaml -}}
{{- if and $dl.enabled (not $dl.hasDnsZone) (or $dl.usesExistingSecret $dl.usesCertManager (ne $dl.managedSecretName "")) -}}
{{- fail "ryvn-gateway gateway.defaultListener.existingSecretName and gateway.defaultListener.certManager.* require gateway.defaultListener.dnsZone" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone $dl.usesExistingSecret $dl.usesCertManager -}}
{{- fail "ryvn-gateway gateway.defaultListener: set either existingSecretName or certManager.issuerRef, not both" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone (not $dl.usesCertManager) (ne $dl.managedSecretName "") -}}
{{- fail "ryvn-gateway gateway.defaultListener.certManager.secretName requires certManager.issuerRef.name" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone (not (or $dl.usesExistingSecret $dl.usesCertManager)) -}}
{{- fail "ryvn-gateway gateway.defaultListener.dnsZone requires either existingSecretName or certManager.issuerRef.name" -}}
{{- end -}}
{{- range $index, $listener := $customListeners -}}
{{- $name := default "" $listener.name -}}
{{- if and $dl.enabled (eq $name "https") -}}
{{- fail (printf "ryvn-gateway gateway.listeners[%d].name=%q collides with the chart-owned default https listener" $index $name) -}}
{{- end -}}
{{- if and $http.enabled (eq $name "http") -}}
{{- fail (printf "ryvn-gateway gateway.listeners[%d].name=%q collides with the chart-owned default http listener" $index $name) -}}
{{- end -}}
{{- end -}}
{{- if not (or $dl.enabled $http.enabled $customListeners) -}}
{{- fail "ryvn-gateway requires at least one listener: keep gateway.defaultListener.enabled=true or specify gateway.listeners" -}}
{{- end -}}
{{- end }}

{{/*
Backward-compatible alias for templates that still include the legacy name.
*/}}
{{- define "ryvn-gateway.validateDefaultListener" -}}
{{- include "ryvn-gateway.validateListeners" . -}}
{{- end }}
