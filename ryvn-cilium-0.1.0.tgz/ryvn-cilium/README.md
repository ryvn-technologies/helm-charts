# ryvn-cilium

Wraps the upstream Cilium chart. It lists that chart twice, and a release turns on
one of them:

| Values key | Installs | Used by |
| --- | --- | --- |
| `cilium` | Cilium itself, as the cluster's CNI | Not yet. ryvn-init still installs the upstream chart on AWS. |
| `hubbleUI` | Only Hubble UI, next to a Hubble Relay the cluster already runs | The `hubble-ui` installation in the AWS, GCP and Azure platform blueprints |

Both default to off, so a release with no values renders nothing.

## Hubble UI

The defaults turn off everything in Cilium's chart except its standalone Hubble UI,
which talks to the Service `hubble-relay` in its own namespace over TLS. Every relay
it runs next to serves TLS and takes the client certificate in the Secret
`hubble-relay-client-certs`: ryvn-init's on AWS, GKE's and AKS's. So
`hubbleUI.enabled: true` is enough, except where the relay's server name isn't the
default `ui.hubble-relay.cilium.io`; GKE sets it in
`hubbleUI.hubble.relay.tls.server.relayName`.

## Cilium as the CNI

When ryvn-init moves to this chart, it nests its values under `cilium` and sets
`cilium.enabled: true`. Rendered through this chart, Helm drops the upstream defaults
that are null, so `cilium-config` loses a few empty keys and the agent its empty
`--k8s-api-server-urls` flag. Nothing changes in how Cilium runs, but the first
upgrade onto this chart restarts the agents once.

## Bumping Cilium

Update both dependency versions and `appVersion` in `Chart.yaml`, then run
`helm dependency update charts/ryvn-cilium`. Render each Hubble UI setup before and
after with `helm template` to check that only the UI's objects change.
