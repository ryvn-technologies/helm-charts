# ryvn-collector

Wraps Grafana Alloy to ship logs, Kubernetes events and Prometheus metrics from a
customer environment to Ryvn's Loki and Mimir, tenanted by organization.

## Scraping a workload's own exporter

Alloy discovers Services annotated for scraping. Annotations live on the
Service; labels used for attribution live on its Endpoints.

| Annotation | Effect |
| --- | --- |
| `ryvn.app/scrape-metrics: "true"` | Required. Opts the Service's ready endpoints into scraping. |
| `ryvn.app/metrics-port` | Port number to scrape. Used verbatim in the target address, so a port *name* does not work. |
| `ryvn.app/metrics-path` | Metrics path; defaults to `/metrics`. |
| `ryvn.app/scrape-interval` | Per-target interval, overriding the chart default. Also lowers the timeout, since a timeout may not exceed its interval. |
| `ryvn.app/scrape-timeout` | Per-target timeout; wins over the value derived from the interval. |
| `ryvn.app/drop-runtime-metrics: "true"` | Drops the exporter's own `go_*`, `process_*` and `promhttp_*` series (`features.metrics.dropMetricNameRegex`). |

| Label | Effect |
| --- | --- |
| `app.kubernetes.io/instance` | Default value of the `installation` label. |
| `ryvn.app/installation-name` | Overrides `installation`, so an exporter deployed beside a resource attributes its series to that resource's installation rather than to the exporter's own release. |
| `app.kubernetes.io/name` | Value of the `service` label. |

Every metric also carries `environment`; the organization is the Mimir tenant
(`X-Scope-OrgID`), not a label. Scoping a query by namespace alone is not
enough: installations in an environment share a namespace, so use `environment`
plus `installation`.

`features.metrics.keepSettingsMetricNames` and `dropSettingsMetricNameRegex`
trim high-cardinality, never-changing series (postgres-exporter reports one
series per server setting); the named metrics survive the drop.

## Destinations and hub identity

Every push to Loki and Mimir carries an OAuth2 client-credentials token. Both
the token endpoint and the ingest gateways are values, so a BYOC hub can point
its attached environments at its own stack instead of Ryvn's:

| Value | Default | Effect |
| --- | --- | --- |
| `endpoints.loki` | `https://loki.ryvn.app` | Base URL of the Loki gateway; the chart appends `/loki/api/v1/push` and `/otlp`. |
| `endpoints.mimir` | `https://mimir.ryvn.app` | Base URL of the Mimir gateway; the chart appends `/api/v1/push`. |
| `auth.tokenUrl` | `https://auth.ryvn.app/oauth/v2/token` | Token endpoint of the Zitadel that issued the collector's client credentials. |
| `auth.projectId` | Ryvn's project | Zitadel project whose audience the token must carry, so the auth-proxy accepts it. |

The rendered Alloy config reads `RYVN_LOKI_URL`, `RYVN_MIMIR_URL`,
`RYVN_TOKEN_URL` and `RYVN_PROJECT_ID` from the collector's environment first
and falls back to these values, so the credentials secret an orchestrator hands
out can carry the destinations too. Trailing slashes on the endpoint URLs are
trimmed either way.

The platform blueprints expose these as `lokiUrl`, `mimirUrl`, `tokenUrl` and
`projectId` inputs.

## Releases

Merging a change to this chart does not release it. The release workflow
(`.github/workflows/ryvn-collector-release.yaml`) fires on PR close and only
when the merged PR carries the `auto-release:ryvn-collector` label, so a PR
merged without it ships nothing. CI generates the release version and rewrites
`Chart.yaml`; the version committed here is not what gets published.

Customer environments subscribe to the `stable` channel through the platform
blueprints, so a new release also has to be promoted into `stable` (and
`production` for Ryvn's own environments) before any environment picks it up.
