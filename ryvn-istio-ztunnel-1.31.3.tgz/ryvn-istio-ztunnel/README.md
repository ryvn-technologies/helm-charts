# ryvn-istio-ztunnel

Wraps Istio's ztunnel chart, pointing at istiod in `ryvn-system` and pulling
Istio images from Docker Hub. Set `global.platform: gke` on GKE. Upstream
overrides go under `ztunnel`. Keep the Helm release name `ztunnel` and
namespace `ryvn-system`.

## Bumping Istio

Set `version`, `appVersion` and the `ztunnel` dependency version in `Chart.yaml` to
the new Istio version and run `helm dependency update charts/ryvn-istio-ztunnel`.
For a new Istio minor, also raise the bounds in `ztunnel-release.ryvn.yaml`. Merge
with the `auto-release:ztunnel` label. Chart versions follow Istio's, so a
values-only change ships with the next Istio version.
