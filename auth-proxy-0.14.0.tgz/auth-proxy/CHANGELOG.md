# Changelog

## 0.2.1

### Changed

* `RYVN_DATASOURCE_SUBJECT_ID` is optional in hub mode; the datasource subject defaults to the `userId` of the `RYVN_HUB_SERVICE_ACCOUNT_FILE` key

## 0.2.0

### Added

* JWT-only token verification and datasource gateway identity settings
* optional hub hosting environment authorization for telemetry ingest
