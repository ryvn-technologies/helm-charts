{{- define "rabbitmq.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "rabbitmq.labels" -}}
app.kubernetes.io/name: rabbitmq
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "rabbitmq.selectorLabelValue" -}}
{{- include "rabbitmq.fullname" . -}}
{{- end -}}

{{- define "rabbitmq.sanitizeName" -}}
{{- $value := lower (printf "%v" .) -}}
{{- $value = regexReplaceAll "[^a-z0-9]+" $value "-" -}}
{{- $value = trimAll "-" $value -}}
{{- if eq $value "" -}}
resource
{{- else -}}
{{- $value | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
