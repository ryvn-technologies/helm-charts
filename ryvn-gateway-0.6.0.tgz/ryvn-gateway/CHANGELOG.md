# Changelog

## 0.5.1 (2026-04-08)

### Breaking

* `IngressProxyTarget.spec.service` is no longer rendered
* removed `ingressCompatibility.proxyTarget.serviceName`

## 0.5.0 (2026-04-04)

### Breaking

* `proxyProtocol.enabled` replaced by `sourceIpPreservation.mode` (direct, proxy-protocol, disabled)
* `service.externalTrafficPolicy` default changed from `Local` to `""` (derived from `sourceIpPreservation.mode`)
* `gateway.className` default changed from `istio` to `ryvn-istio`
* `ingressCompatibilityProfile` + `gateway.role` now drive defaults for Service type and compatibility resources
* `service.type` is an override; profile sets the default when cleared to `""`

### Added

* `sourceIpPreservation.mode` with `numTrustedProxies` for `gatewayTopology` annotation
* `IngressClass` auto-created for `create` profile, `IngressProxyTarget` for `adopt`
* `metricsService` for dedicated Envoy stats scraping (port 15020, built-in `ryvn.app/scrape-*` annotations)
* `telemetry` resource for Istio metric label drops
* profile defaults are overrideable through chart values

## 0.3.0 (2026-04-02)

### Breaking

* `defaultListener` moved under `gateway.defaultListener`
* TLS config flattened to `dnsZone`, `existingSecretName`, `certManager.*`

### Added

* HTTPS listener on 443 with self-signed placeholder cert by default
* `dnsZone` scopes the listener to a wildcard domain
* `existingSecretName` or `certManager.issuerRef` for TLS

## 0.2.0 (2026-03-18)

### Breaking

* istio/gateway subchart replaced with a Gateway API `Gateway` resource
* new top-level values: `gateway`, `deployment`, `service`, `infrastructure`

### Added

* Gateway resource with `parametersRef` ConfigMap for Service and Deployment
* Service defaults to `ClusterIP`, `LoadBalancer` opt-in
* HPA and PDB generation
* cross-namespace ListenerSet attachment
* proxy protocol opt-in via gateway pod annotation

## 0.1.2 (2026-03-06)

### Fixed

* `defaults.maxBodySize` replaced with typed `defaults.maxBodySizeBytes`

## 0.1.1 (2026-03-06)

### Fixed

* EnvoyFilter workload selectors now match gateway labels
* `defaults.maxBodySize` off by default (unlimited until explicitly set)

## 0.1.0 (2026-03-04)

* initial release: Istio gateway 1.29.0 with Envoy defaults
* `defaults.maxBodySize` for request body size limit via EnvoyFilter
