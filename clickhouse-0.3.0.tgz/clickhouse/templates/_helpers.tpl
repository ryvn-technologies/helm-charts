{{- define "clickhouse.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "clickhouse.keeperName" -}}
{{- printf "%s-keeper" (include "clickhouse.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "clickhouse.labels" -}}
app.kubernetes.io/name: clickhouse
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "clickhouse.authSecretName" -}}
{{- if .Values.defaultUserPassword -}}
{{- printf "%s-default-user" (include "clickhouse.fullname" .) -}}
{{- else -}}
{{- .Values.defaultUserPasswordSecretName -}}
{{- end -}}
{{- end -}}
