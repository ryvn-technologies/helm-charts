{{/*
Expand the name of the chart.
*/}}
{{- define "web-server.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "web-server.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "web-server.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "web-server.serviceName" -}}
{{- default .Release.Name .Values.serviceName }}
{{- end }}

{{/*
Common labels +
Ryvn specific labels
*/}}
{{- define "web-server.labels" -}}
ryvn.app/service-name: {{ include "web-server.serviceName" . }}
helm.sh/chart: {{ include "web-server.chart" . }}
{{ include "web-server.selectorLabels" . }}
{{/*
Version label priority: releaseVersion > image.tag > Chart.AppVersion
Using image.tag as fallback ensures the version label reflects the actual deployed image,
which is picked up by ryvn-collector (Alloy) for observability labels.
Note: image.tag is only used if it's a valid Kubernetes label value:
- Max 63 characters
- Only alphanumerics, dashes, underscores, dots
- Must start and end with alphanumeric
*/}}
{{- $validLabelValue := "^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?$|^[a-zA-Z0-9]$" -}}
{{- if .Values.releaseVersion }}
app.kubernetes.io/version: {{ .Values.releaseVersion | quote }}
ryvn.app/release-version: {{ .Values.releaseVersion | quote }}
{{- else if and .Values.image.tag (le (len .Values.image.tag) 63) (regexMatch $validLabelValue .Values.image.tag) }}
app.kubernetes.io/version: {{ .Values.image.tag | quote }}
{{- else if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "web-server.selectorLabels" -}}
app.kubernetes.io/name: {{ include "web-server.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use.
Defaults to the release name so the SA is named after the installation,
not the chart. Override via .Values.serviceAccount.name if needed.
*/}}
{{- define "web-server.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default .Release.Name .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}
