{{- define "ryvn-net.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ryvn-net.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "ryvn-net.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Suffixed names truncate the base so the full name stays within the 63-char
object-name limit even for long release names: "-metrics" is 8 chars,
"-leader-election" is 16.
*/}}
{{- define "ryvn-net.metricsName" -}}
{{- printf "%s-metrics" (include "ryvn-net.fullname" . | trunc 55 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.leaderElectionName" -}}
{{- printf "%s-leader-election" (include "ryvn-net.fullname" . | trunc 47 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.labels" -}}
helm.sh/chart: {{ include "ryvn-net.chart" . }}
{{ include "ryvn-net.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/component: networking-operator
{{- end }}

{{- define "ryvn-net.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-net.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "ryvn-net.serviceAccountName" -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "ryvn-net.fullname" . -}}
{{- end -}}
{{- end }}

{{- define "ryvn-net.image" -}}
{{- $tag := default .Chart.AppVersion .Values.image.tag -}}
{{ printf "%s:%s" .Values.image.repository $tag }}
{{- end }}

{{/*
Suffix lengths: "-webhook" 8, "-webhook-tls" 12, "-routes" 7, "-webhook-bootstrap" 18, "-webhook-ca" 11.
*/}}
{{- define "ryvn-net.webhookName" -}}
{{- printf "%s-webhook" (include "ryvn-net.fullname" . | trunc 55 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.webhookTLSSecretName" -}}
{{- printf "%s-webhook-tls" (include "ryvn-net.fullname" . | trunc 51 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.webhookConfigurationName" -}}
{{- printf "%s-routes" (include "ryvn-net.fullname" . | trunc 56 | trimSuffix "-") }}
{{- end }}

{{/*
The webhook Service selects on this label, so pods from a release without the
webhook are never its endpoints.
*/}}
{{- define "ryvn-net.webhookPodLabels" -}}
networking.ryvn.app/webhook: route
{{- end }}

{{- define "ryvn-net.webhookBootstrapIssuerName" -}}
{{- printf "%s-webhook-bootstrap" (include "ryvn-net.fullname" . | trunc 45 | trimSuffix "-") }}
{{- end }}

{{- define "ryvn-net.webhookCAName" -}}
{{- printf "%s-webhook-ca" (include "ryvn-net.fullname" . | trunc 52 | trimSuffix "-") }}
{{- end }}

{{/*
Adds preferred anti-affinity by hostname unless .Values.affinity already sets podAntiAffinity.
*/}}
{{- define "ryvn-net.affinity" -}}
{{- $affinity := deepCopy (.Values.affinity | default dict) -}}
{{- if not (hasKey $affinity "podAntiAffinity") -}}
{{- $selector := dict "matchLabels" (include "ryvn-net.selectorLabels" . | fromYaml) -}}
{{- $term := dict "weight" 100 "podAffinityTerm" (dict "topologyKey" "kubernetes.io/hostname" "labelSelector" $selector) -}}
{{- $_ := set $affinity "podAntiAffinity" (dict "preferredDuringSchedulingIgnoredDuringExecution" (list $term)) -}}
{{- end -}}
{{- toYaml $affinity -}}
{{- end }}
