# ryvn-istiod

Wraps Istio's istiod chart with Ryvn's control plane settings: `ryvn-istio` as the
default GatewayClass, the mesh config that ryvn-net shares, multiple custom
authorization providers, and gateway access logs without query strings. Images come
from Docker Hub. Upstream overrides go under `istiod`. `global` values reach the
subchart as-is, so `global.profile: ambient` turns on ambient mode. Keep the Helm
release name `istiod` and namespace `ryvn-system`.

## Bumping Istio

Set `version`, `appVersion` and the `istiod` dependency version in `Chart.yaml` to the
new Istio version and run `helm dependency update charts/ryvn-istiod`. Bump
`charts/ryvn-istio-base` in the same PR. For a new Istio minor, also raise the bounds
in `istiod-release.ryvn.yaml`, `ztunnel-release.ryvn.yaml` and
`istio-cni-release.ryvn.yaml`. Merge with the `auto-release:istiod` label. Chart
versions follow Istio's, so a values-only change ships with the next Istio version;
until then, override it in the blueprint under `istiod`.
