# ryvn-istio-cni

Wraps Istio's CNI chart for ambient mode. It excludes `kube-system` and
`ryvn-system` from enrollment and pulls Istio images from Docker Hub.

Set `global.platform: gke` on GKE. Upstream CNI overrides go under `cni`,
including `cni.ambient.enablementSelectors` for custom namespace enrollment.
Keep the Helm release name `istio-cni` and namespace `ryvn-system`.

## Bumping Istio

Set `version`, `appVersion` and the `cni` dependency version in `Chart.yaml` to the
new Istio version and run `helm dependency update charts/ryvn-istio-cni`. For a new
Istio minor, also raise the bounds in `istio-cni-release.ryvn.yaml`. Merge with the
`auto-release:istio-cni` label. Chart versions follow Istio's, so a values-only
change ships with the next Istio version.
