# Changelog

## [0.4.1](https://github.com/ryvn-technologies/ryvn/compare/cluster-issuer@v0.4.0...cluster-issuer@v0.4.1) (2025-10-01)


### Bug Fixes

* add external-issuer for older envs ([#2776](https://github.com/ryvn-technologies/ryvn/issues/2776)) ([cea2269](https://github.com/ryvn-technologies/ryvn/commit/cea22696518cbf0f3de503d58976cec98d9f2a59))

## [0.4.0](https://github.com/ryvn-technologies/ryvn/compare/cluster-issuer@v0.3.1...cluster-issuer@v0.4.0) (2025-06-30)


### Features

* **cluster-issuer:** create wildcard cert ([#2009](https://github.com/ryvn-technologies/ryvn/issues/2009)) ([1032385](https://github.com/ryvn-technologies/ryvn/commit/1032385f6baa8e0ed427d875ab3f4fdc8adfb9aa))

## [0.3.1](https://github.com/ryvn-technologies/ryvn/compare/cluster-issuer@v0.3.0...cluster-issuer@v0.3.1) (2025-06-30)


### Bug Fixes

* cluster issuer indent ([b3f9120](https://github.com/ryvn-technologies/ryvn/commit/b3f9120aca3e92fd0c62c7e0b05fc6af74f3457a))

## [0.3.0](https://github.com/ryvn-technologies/ryvn/compare/cluster-issuer@v0.2.0...cluster-issuer@v0.3.0) (2025-06-29)


### Features

* **cluster-issuer:** dns-01 challenge for wildcard certs ([#1999](https://github.com/ryvn-technologies/ryvn/issues/1999)) ([6a6f0db](https://github.com/ryvn-technologies/ryvn/commit/6a6f0dbd507cdac87e896e630bad00f5904235f4))

## [0.2.0](https://github.com/ryvn-technologies/ryvn/compare/cluster-issuer@v0.1.0...cluster-issuer@v0.2.0) (2025-03-06)


### Features

* release cluster issuer ([4c95495](https://github.com/ryvn-technologies/ryvn/commit/4c95495ec3b7b51d3670ea8e8e34a758124b8481))
* release cluster issuer ([6de26f4](https://github.com/ryvn-technologies/ryvn/commit/6de26f47f7eab6d8d415ef15b9eb350b5fdb591c))
* update prod-issuer chart ([d8d08bc](https://github.com/ryvn-technologies/ryvn/commit/d8d08bc61e7f8ebdecfedf2a18e94069ea7cfcdd))
