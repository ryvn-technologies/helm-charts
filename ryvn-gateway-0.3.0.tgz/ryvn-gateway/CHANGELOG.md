# Changelog

## 0.2.0 (2026-03-18)

### Breaking Changes

* replace istio/gateway subchart with a Gateway API `Gateway` resource; Istio auto-provisions the Deployment and Service
* replace the old `gateway` pass-through with chart-owned `gateway`, `deployment`, `service`, and `infrastructure` values

### Features

* render a Gateway resource plus a `parametersRef` ConfigMap for the generated Service and Deployment
* default the generated Service to `ClusterIP`, with release-specific Service annotations and `LoadBalancer` opt-in
* add deployment sizing and scheduling values plus optional HPA and PDB generation
* allow cross-namespace ListenerSet attachment, with optional selector scoping
* support chart-owned default listeners, with a temporary dummy listener fallback when none are configured
* add proxy protocol opt-in via gateway pod annotation
* target the chart-owned max-body-size EnvoyFilter at the Gateway resource

## 0.1.2 (2026-03-06)

### Fixes

* replace string-based `defaults.maxBodySize` parsing with typed `defaults.maxBodySizeBytes`
* validate `defaults.maxBodySizeBytes` via `values.schema.json` instead of template-side conversion logic

## 0.1.1 (2026-03-06)

### Fixes

* match EnvoyFilter workload selectors to the upstream gateway chart's `istio` label behavior
* validate and normalize `defaults.maxBodySize.value` parsing instead of silently rendering invalid sizes as `0`
* disable `defaults.maxBodySize` by default to keep request bodies unlimited until an explicit baseline is chosen

## 0.1.0 (2026-03-04)

### Features

* initial release wrapping Istio gateway 1.29.0 with gateway-wide Envoy defaults
* add `defaults.maxBodySize` for gateway-wide request body size limit via EnvoyFilter
