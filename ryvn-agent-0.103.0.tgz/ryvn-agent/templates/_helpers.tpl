{{/*
Expand the name of the k8s-agent.
*/}}
{{- define "chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains k8s-agent name it will be used as a full name.
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create k8s-agent name and version as used by the k8s-agent label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "chart.labels" -}}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name - uses existing name if provided, otherwise falls back to chart fullname
*/}}
{{- define "chart.serviceAccountName" -}}
{{- if .Values.serviceAccount.name -}}
{{- .Values.serviceAccount.name -}}
{{- else -}}
{{- include "chart.fullname" . -}}
{{- end -}}
{{- end }}

{{/*
Target environment - uses targetEnv if set, otherwise falls back to ryvn.env.name
*/}}
{{- define "targetEnvironment" -}}
{{- if .Values.targetEnv -}}
{{- .Values.targetEnv -}}
{{- else if .Values.ryvn -}}
{{- .Values.ryvn.env.name -}}
{{- end -}}
{{- end }}

{{/*
Effective i2gw controller mode. Explicit i2gw.mode wins; otherwise derive
from the profile: "create" means apply, "adopt" means observe-only. Falls
back to observe-only when neither is set.
*/}}
{{- define "i2gw.effectiveMode" -}}
{{- $explicit := trim (.Values.i2gw.mode | default "") -}}
{{- if ne $explicit "" -}}
{{- $explicit -}}
{{- else -}}
{{- $profile := trim (.Values.i2gw.ingressCompatibilityProfile | default "") -}}
{{- if eq $profile "create" -}}apply{{- else -}}observe-only{{- end -}}
{{- end -}}
{{- end }}

{{/*
Whether the i2gw validating webhook should be rendered and started.
i2gw.webhook.enabled is a nullable bool: unset follows the effective
controller mode (on in apply, off in observe-only), false forces off, true
forces on and fails when the effective mode is not apply (admission must not
enforce translations in observe-only).
*/}}
{{- define "i2gw.webhookEnabled" -}}
{{- $explicit := .Values.i2gw.webhook.enabled -}}
{{- $effectiveMode := include "i2gw.effectiveMode" . -}}
{{- if not .Values.i2gw.enabled -}}
false
{{- else if and (kindIs "bool" $explicit) (not $explicit) -}}
false
{{- else if and (kindIs "bool" $explicit) $explicit -}}
{{- if ne $effectiveMode "apply" -}}
{{- fail "i2gw.webhook.enabled=true requires effective controller mode apply" -}}
{{- end -}}
true
{{- else if eq $effectiveMode "apply" -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Whether i2gw controller metrics should be registered and exposed.
Metrics default on in apply mode and off otherwise. A boolean
i2gw.metrics.enabled value is an explicit override.
*/}}
{{- define "i2gw.metricsEnabled" -}}
{{- $explicit := .Values.i2gw.metrics.enabled -}}
{{- $effectiveMode := include "i2gw.effectiveMode" . -}}
{{- if not .Values.i2gw.enabled -}}
false
{{- else if kindIs "bool" $explicit -}}
{{- ternary "true" "false" $explicit -}}
{{- else if eq $effectiveMode "apply" -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
CEL list of ingress classes managed by i2gw.
Explicit ingressClassMapping wins. If it is omitted, derive classes from the
same built-in ingressCompatibilityProfile defaults used by the agent.
*/}}
{{- define "i2gw.managedIngressClassCELList" -}}
{{- $classes := list -}}
{{- $mapping := trim .Values.i2gw.ingressClassMapping -}}
{{- if $mapping -}}
{{- range $entry := splitList "," $mapping -}}
{{- $entry = trim $entry -}}
{{- if $entry -}}
{{- $parts := splitList "=" $entry -}}
{{- $class := trim (index $parts 0) -}}
{{- if $class -}}
{{- $classes = append $classes (printf "%q" $class) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- else -}}
{{- $profile := trim .Values.i2gw.ingressCompatibilityProfile -}}
{{- if or (eq $profile "adopt") (eq $profile "create") -}}
{{- $classes = append $classes (printf "%q" "external-nginx") -}}
{{- $classes = append $classes (printf "%q" "internal-nginx") -}}
{{- end -}}
{{- end -}}
[{{ join ", " $classes }}]
{{- end }}
