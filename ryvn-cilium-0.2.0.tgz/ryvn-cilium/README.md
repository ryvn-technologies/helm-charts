# ryvn-cilium

Wraps the upstream Cilium chart. It lists that chart twice, and a release turns on
one of them:

| Values key | Installs | Used by |
| --- | --- | --- |
| `cilium` | Cilium itself, as the cluster's CNI | Nothing yet. ryvn-init still installs the upstream chart on AWS, and `values.schema.json` keeps this part off. |
| `hubbleUI` | Only Hubble UI, next to a Hubble Relay the cluster already runs | The `cilium-hubble-ui` blueprint |

Both default to off, so a release with no values renders nothing.

## Hubble UI

The defaults turn off everything in Cilium's chart except its standalone Hubble UI,
which talks to the Service `hubble-relay` in its own namespace over TLS. Every relay
it runs next to serves TLS and takes the client certificate in the Secret
`hubble-relay-client-certs`: ryvn-init's on AWS, GKE's and AKS's. So
`hubbleUI.enabled: true` is enough, except where the relay's server name isn't the
default `ui.hubble-relay.cilium.io`; GKE sets it in
`hubbleUI.hubble.relay.tls.server.relayName`.

## What a release can turn on

`values.schema.json` pins every switch that installs another part of Cilium to off:
the agent, operator, Envoy, a second relay, clustermesh and the rest. Helm checks it
on every install and upgrade, so editing an installation's values can't turn one on.

## Cilium as the CNI

When ryvn-init moves to this chart, remove the `cilium` pin from `values.schema.json`,
nest ryvn-init's values under `cilium` and set `cilium.enabled: true`. Rendered
through this chart, Helm drops the upstream defaults that are null, so `cilium-config`
loses a few empty keys and the agent its empty `--k8s-api-server-urls` flag. Nothing
changes in how Cilium runs, but the first upgrade onto this chart restarts the agents
once.

## Bumping Cilium

Update both dependency versions and `appVersion` in `Chart.yaml`, then run
`helm dependency update charts/ryvn-cilium`. Render each Hubble UI setup before and
after with `helm template` to check that only the UI's objects change.

A new Cilium version can add parts with their own switches. List the templates'
top-level conditions for the old and new version, then pin any new switch in
`values.schema.json`:

```bash
helm pull oci://quay.io/cilium/charts/cilium --version "$VERSION" --untar -d "/tmp/cilium-$VERSION"
grep -rhE '^\{\{-? *if ' "/tmp/cilium-$VERSION/cilium/templates" | sort -u > "/tmp/cilium-$VERSION.conditions"
diff "/tmp/cilium-$OLD_VERSION.conditions" "/tmp/cilium-$VERSION.conditions"
```
