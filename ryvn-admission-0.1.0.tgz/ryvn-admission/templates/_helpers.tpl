{{/*
Admission policies are cluster-wide singletons. Networking is the only policy
today.
*/}}
{{- define "ryvn-admission.networking.name" -}}
networking.ryvn.app
{{- end }}

{{/*
Managed markers as a CEL expression. A marker without allowedValues checks
label presence; a marker with allowedValues checks both presence and value.
*/}}
{{- define "ryvn-admission.networking.managedMarkersCEL" -}}
{{- $expressions := list -}}
{{- range $marker := . -}}
  {{- $label := $marker.label | toJson -}}
  {{- $expression := printf "%s in object.metadata.labels" $label -}}
  {{- with $marker.allowedValues -}}
    {{- $expression = printf "(%s &&\n  object.metadata.labels[%s] in %s)" $expression $label (toJson .) -}}
  {{- end -}}
  {{- $expressions = append $expressions $expression -}}
{{- end -}}
{{- join " ||\n" $expressions -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ryvn-admission.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: ryvn
{{- end }}
