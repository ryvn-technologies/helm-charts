{{/*
Expand the name of the chart.
*/}}
{{- define "ryvn-gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "ryvn-gateway.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "ryvn-gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ryvn-gateway.labels" -}}
helm.sh/chart: {{ include "ryvn-gateway.chart" . }}
{{ include "ryvn-gateway.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ryvn-gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ryvn-gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Normalize the chart-owned default HTTPS listener settings.
*/}}
{{- define "ryvn-gateway.defaultListenerConfig" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $dl := $gateway.defaultListener | default (dict) -}}
{{- $enabled := ternary $dl.enabled true (hasKey $dl "enabled") -}}
{{- $dnsZone := default "" $dl.dnsZone -}}
{{- $hasDnsZone := ne $dnsZone "" -}}
{{- $certManager := $dl.certManager | default (dict) -}}
{{- $issuerRef := $certManager.issuerRef | default (dict) -}}
{{- $hasExistingSecret := ne (default "" $dl.existingSecretName) "" -}}
{{- $hasIssuerRef := ne (default "" $issuerRef.name) "" -}}
{{- $managedSecretName := default "" $certManager.secretName -}}
{{- $secretName := printf "%s-default-tls" (include "ryvn-gateway.fullname" .) -}}
{{- if $hasExistingSecret -}}
{{- $secretName = $dl.existingSecretName -}}
{{- else if ne $managedSecretName "" -}}
{{- $secretName = $managedSecretName -}}
{{- else if $hasDnsZone -}}
{{- $secretName = printf "%s-gw-wildcard-tls" $dnsZone -}}
{{- end -}}
{{- $certName := printf "%s-default-tls" (include "ryvn-gateway.fullname" .) -}}
{{- if $hasDnsZone -}}
{{- $certName = printf "%s-gw-wildcard" $dnsZone -}}
{{- end -}}
enabled: {{ $enabled }}
certName: {{ $certName | quote }}
hasDnsZone: {{ $hasDnsZone }}
dnsZone: {{ $dnsZone | quote }}
hostname: {{ ternary (printf "*.%s" $dnsZone) "" $hasDnsZone | quote }}
usesExistingSecret: {{ $hasExistingSecret }}
usesCertManager: {{ $hasIssuerRef }}
managedSecretName: {{ $managedSecretName | quote }}
secretName: {{ $secretName | quote }}
{{- if $hasDnsZone }}
dnsNames:
  - {{ printf "*.%s" $dnsZone | quote }}
  - {{ $dnsZone | quote }}
{{- end }}
{{- if $hasIssuerRef }}
issuerRef:
  name: {{ $issuerRef.name | quote }}
  kind: {{ default "Issuer" $issuerRef.kind | quote }}
{{- end }}
{{- end }}

{{/*
Validate the chart-owned default HTTPS listener values.
*/}}
{{- define "ryvn-gateway.validateDefaultListener" -}}
{{- $gateway := .Values.gateway | default (dict) -}}
{{- $customListeners := $gateway.listeners | default (list) -}}
{{- $dl := include "ryvn-gateway.defaultListenerConfig" . | fromYaml -}}
{{- if and $dl.enabled (not $dl.hasDnsZone) (or $dl.usesExistingSecret $dl.usesCertManager (ne $dl.managedSecretName "")) -}}
{{- fail "ryvn-gateway gateway.defaultListener.existingSecretName and gateway.defaultListener.certManager.* require gateway.defaultListener.dnsZone" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone $dl.usesExistingSecret $dl.usesCertManager -}}
{{- fail "ryvn-gateway gateway.defaultListener: set either existingSecretName or certManager.issuerRef, not both" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone (not $dl.usesCertManager) (ne $dl.managedSecretName "") -}}
{{- fail "ryvn-gateway gateway.defaultListener.certManager.secretName requires certManager.issuerRef.name" -}}
{{- end -}}
{{- if and $dl.enabled $dl.hasDnsZone (not (or $dl.usesExistingSecret $dl.usesCertManager)) -}}
{{- fail "ryvn-gateway gateway.defaultListener.dnsZone requires either existingSecretName or certManager.issuerRef.name" -}}
{{- end -}}
{{- if not (or $dl.enabled $customListeners) -}}
{{- fail "ryvn-gateway requires at least one listener: keep gateway.defaultListener.enabled=true or specify gateway.listeners" -}}
{{- end -}}
{{- end }}
