{{/*
Expand the name of the chart.
*/}}
{{- define "chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Chart name and version as used by the chart label.
*/}}
{{- define "chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "chart.labels" -}}
helm.sh/chart: {{ include "chart.chart" . }}
{{ include "chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Service account name — FIXED to "ryvn-access-relay" and intentionally NOT
overridable. The hub's RFC 19 access-RBAC impersonator ClusterRoleBinding
targets this exact SA name (see internal/manifest/access_rbac.go:
ryvnAccessRelayServiceAccountName). If the name could vary, that binding
would silently point at a nonexistent subject and impersonated ryvn:* sessions
would 403. Keep this literal in sync with that constant.
*/}}
{{- define "chart.serviceAccountName" -}}
ryvn-access-relay
{{- end }}

{{/*
Name of the Kubernetes Secret holding the relay's Zitadel credential bundle.

RFC 19: the credential is delivered as an ordinary installation secret by the
access-relay managed add-on. The Ryvn agent materializes it into the
installation namespace under the composed name
normalize("<installationName>-<secretName>"), which the hub passes down as
.Values.credentials.secretName (via {{ k8sSecretName "credentials" }}). When
that value is absent (e.g. a standalone `helm install` outside Ryvn), fall back
to the conventional composed name for this chart's fixed release name.
*/}}
{{- define "chart.credentialsSecretName" -}}
{{- if and .Values.credentials .Values.credentials.secretName -}}
{{- .Values.credentials.secretName -}}
{{- else -}}
ryvn-access-relay-credentials
{{- end -}}
{{- end }}

{{/*
Target environment - uses targetEnv if set, otherwise falls back to ryvn.env.name
*/}}
{{- define "targetEnvironment" -}}
{{- if .Values.targetEnv -}}
{{- .Values.targetEnv -}}
{{- else if .Values.ryvn -}}
{{- .Values.ryvn.env.name -}}
{{- end -}}
{{- end }}
